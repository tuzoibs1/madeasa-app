from flask import Blueprint, request, jsonify
from src.models import db
from src.models.lesson_model import Lesson, LessonContentType
from src.models.class_model import Class
from src.models.user_model import UserRole
from src.utils.auth import token_required, role_required

lesson_bp = Blueprint("lesson_bp", __name__, url_prefix="/api/lessons")

# Create a new lesson (Teacher, Director)
@lesson_bp.route("/", methods=["POST"])
@token_required
@role_required([UserRole.TEACHER, UserRole.DIRECTOR])
def create_lesson(current_user):
    data = request.get_json()
    required_fields = ["class_id", "title"]
    if not all(field in data for field in required_fields):
        return jsonify({"message": f"Missing required fields: {", ".join(required_fields)}"}), 400

    try:
        class_id = int(data["class_id"])
        title = data["title"]
        content_type_str = data.get("content_type", "Text") # Default to Text
        content_value = data.get("content_value")
        lesson_order = data.get("lesson_order")
        if lesson_order is not None:
            lesson_order = int(lesson_order)
    except ValueError:
        return jsonify({"message": "Invalid data type for class_id or lesson_order."}), 400

    target_class = Class.query.get(class_id)
    if not target_class:
        return jsonify({"message": "Class not found"}), 404

    # Authorization: Teacher can only add lessons to classes they teach (unless Director)
    if request.current_user_role == UserRole.TEACHER and target_class.teacher_id != current_user.user_id:
        return jsonify({"message": "Teachers can only add lessons to their own classes."}), 403

    try:
        content_type = LessonContentType(content_type_str)
    except ValueError:
        return jsonify({"message": f"Invalid content_type. Must be one of: {[ct.value for ct in LessonContentType]}"}), 400

    try:
        new_lesson = Lesson(
            class_id=class_id,
            title=title,
            content_type=content_type,
            content_value=content_value,
            lesson_order=lesson_order
        )
        db.session.add(new_lesson)
        db.session.commit()
        return jsonify({
            "message": "Lesson created successfully!",
            "lesson": {
                "lesson_id": new_lesson.lesson_id,
                "class_id": new_lesson.class_id,
                "title": new_lesson.title,
                "content_type": new_lesson.content_type.value,
                "content_value": new_lesson.content_value,
                "lesson_order": new_lesson.lesson_order,
                "created_at": new_lesson.created_at.isoformat(),
                "updated_at": new_lesson.updated_at.isoformat()
            }
        }), 201
    except Exception as e:
        db.session.rollback()
        return jsonify({"message": "Error creating lesson", "error": str(e)}), 500

# Get all lessons for a class (All roles, if enrolled or teaching/directing)
@lesson_bp.route("/class/<int:class_id>", methods=["GET"])
@token_required
def get_lessons_for_class(current_user, class_id):
    target_class = Class.query.get(class_id)
    if not target_class:
        return jsonify({"message": "Class not found"}), 404

    # Authorization: Students must be enrolled, Teachers must teach the class (unless Director)
    # This is a simplified check for MVP. A more robust check would verify enrollment/teaching status.
    if request.current_user_role == UserRole.STUDENT:
        from src.models.enrollment_model import Enrollment # avoid circular import
        enrollment = Enrollment.query.filter_by(student_id=current_user.user_id, class_id=class_id, status="Active").first()
        if not enrollment:
            return jsonify({"message": "Access denied. Student not actively enrolled in this class."}), 403
    elif request.current_user_role == UserRole.TEACHER and target_class.teacher_id != current_user.user_id:
         return jsonify({"message": "Teachers can only view lessons for their own classes."}), 403

    lessons = Lesson.query.filter_by(class_id=class_id).order_by(Lesson.lesson_order.asc(), Lesson.lesson_id.asc()).all()
    output = []
    for lesson in lessons:
        output.append({
            "lesson_id": lesson.lesson_id,
            "class_id": lesson.class_id,
            "title": lesson.title,
            "content_type": lesson.content_type.value,
            "content_value": lesson.content_value, # Consider if full content should always be returned
            "lesson_order": lesson.lesson_order,
            "created_at": lesson.created_at.isoformat(),
            "updated_at": lesson.updated_at.isoformat()
        })
    return jsonify(output), 200

# Get a specific lesson (All roles, if authorized for the class)
@lesson_bp.route("/<int:lesson_id>", methods=["GET"])
@token_required
def get_lesson(current_user, lesson_id):
    lesson = Lesson.query.get(lesson_id)
    if not lesson:
        return jsonify({"message": "Lesson not found"}), 404

    target_class = Class.query.get(lesson.class_id)
    # Authorization (similar to get_lessons_for_class)
    if request.current_user_role == UserRole.STUDENT:
        from src.models.enrollment_model import Enrollment
        enrollment = Enrollment.query.filter_by(student_id=current_user.user_id, class_id=lesson.class_id, status="Active").first()
        if not enrollment:
            return jsonify({"message": "Access denied. Student not actively enrolled in the class of this lesson."}), 403
    elif request.current_user_role == UserRole.TEACHER and target_class.teacher_id != current_user.user_id:
         return jsonify({"message": "Teachers can only view lessons for their own classes."}), 403

    return jsonify({
        "lesson_id": lesson.lesson_id,
        "class_id": lesson.class_id,
        "title": lesson.title,
        "content_type": lesson.content_type.value,
        "content_value": lesson.content_value,
        "lesson_order": lesson.lesson_order,
        "created_at": lesson.created_at.isoformat(),
        "updated_at": lesson.updated_at.isoformat()
    }), 200

# Update a lesson (Teacher who owns class, Director)
@lesson_bp.route("/<int:lesson_id>", methods=["PUT"])
@token_required
@role_required([UserRole.TEACHER, UserRole.DIRECTOR])
def update_lesson(current_user, lesson_id):
    lesson = Lesson.query.get(lesson_id)
    if not lesson:
        return jsonify({"message": "Lesson not found"}), 404

    target_class = Class.query.get(lesson.class_id)
    # Authorization: Teacher must teach the class of this lesson (unless Director)
    if request.current_user_role == UserRole.TEACHER and target_class.teacher_id != current_user.user_id:
        return jsonify({"message": "Teachers can only update lessons in their own classes."}), 403

    data = request.get_json()
    if not data:
        return jsonify({"message": "No data provided for update"}), 400

    try:
        if "title" in data: lesson.title = data["title"]
        if "content_type" in data:
            lesson.content_type = LessonContentType(data["content_type"])
        if "content_value" in data: lesson.content_value = data["content_value"]
        if "lesson_order" in data:
            lesson.lesson_order = int(data["lesson_order"]) if data["lesson_order"] is not None else None
        
        lesson.updated_at = db.func.current_timestamp()
        db.session.commit()
        return jsonify({"message": "Lesson updated successfully!", "lesson_id": lesson.lesson_id}), 200
    except ValueError as ve:
         return jsonify({"message": f"Invalid data: {str(ve)}"}), 400
    except Exception as e:
        db.session.rollback()
        return jsonify({"message": "Error updating lesson", "error": str(e)}), 500

# Delete a lesson (Teacher who owns class, Director)
@lesson_bp.route("/<int:lesson_id>", methods=["DELETE"])
@token_required
@role_required([UserRole.TEACHER, UserRole.DIRECTOR])
def delete_lesson(current_user, lesson_id):
    lesson = Lesson.query.get(lesson_id)
    if not lesson:
        return jsonify({"message": "Lesson not found"}), 404

    target_class = Class.query.get(lesson.class_id)
    # Authorization: Teacher must teach the class of this lesson (unless Director)
    if request.current_user_role == UserRole.TEACHER and target_class.teacher_id != current_user.user_id:
        return jsonify({"message": "Teachers can only delete lessons in their own classes."}), 403

    try:
        db.session.delete(lesson)
        db.session.commit()
        return jsonify({"message": "Lesson deleted successfully!"}), 200
    except Exception as e:
        db.session.rollback()
        # Check for integrity errors if quizzes or other dependent items exist and cascade is not set appropriately
        return jsonify({"message": "Error deleting lesson", "error": str(e)}), 500

