from src.models import db
from datetime import datetime
import enum
from src.models.user_model import User # Import User for relationships
from src.models.class_model import Class # Import Class for relationships

class EnrollmentStatus(enum.Enum):
    ACTIVE = "Active"
    COMPLETED = "Completed"
    DROPPED = "Dropped"

class Enrollment(db.Model):
    __tablename__ = "enrollment"

    enrollment_id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    student_id = db.Column(db.Integer, db.ForeignKey("users.user_id"), nullable=False)
    class_id = db.Column(db.Integer, db.ForeignKey("classes.class_id"), nullable=False)
    enrollment_date = db.Column(db.Date, nullable=False, default=datetime.utcnow)
    status = db.Column(db.Enum(EnrollmentStatus), default=EnrollmentStatus.ACTIVE)
    created_at = db.Column(db.TIMESTAMP, default=datetime.utcnow)
    updated_at = db.Column(db.TIMESTAMP, default=datetime.utcnow, onupdate=datetime.utcnow)

    # Relationships
    student = db.relationship("User", back_populates="enrollments")
    class_obj = db.relationship("Class", back_populates="enrollments")
    attendances = db.relationship("Attendance", back_populates="enrollment", lazy=True, cascade="all, delete-orphan")

    __table_args__ = (db.UniqueConstraint("student_id", "class_id", name="uq_student_class_enrollment"),)

    def __init__(self, student_id, class_id, enrollment_date=None, status=EnrollmentStatus.ACTIVE):
        self.student_id = student_id
        self.class_id = class_id
        self.enrollment_date = enrollment_date if enrollment_date else datetime.utcnow().date()
        self.status = status

    def __repr__(self):
        return f"<Enrollment {self.enrollment_id}: Student {self.student_id} in Class {self.class_id}>"

