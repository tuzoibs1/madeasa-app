from src.models import db
import enum
from datetime import datetime
import bcrypt # For password hashing

class UserRole(enum.Enum):
    DIRECTOR = "Director"
    TEACHER = "Teacher"
    STUDENT = "Student"

class User(db.Model):
    __tablename__ = "users"

    user_id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    full_name = db.Column(db.String(255), nullable=False)
    email = db.Column(db.String(255), nullable=False, unique=True)
    password_hash = db.Column(db.String(255), nullable=False)
    role = db.Column(db.Enum(UserRole), nullable=False)
    created_at = db.Column(db.TIMESTAMP, default=datetime.utcnow)
    updated_at = db.Column(db.TIMESTAMP, default=datetime.utcnow, onupdate=datetime.utcnow)

    # Relationships
    # For Teacher role
    taught_classes = db.relationship("Class", foreign_keys="Class.teacher_id", back_populates="teacher", lazy=True)
    # For Student role
    enrollments = db.relationship("Enrollment", back_populates="student", lazy=True)
    memorization_progress = db.relationship("MemorizationProgress", back_populates="student", lazy=True)
    quiz_attempts = db.relationship("QuizAttempt", back_populates="student", lazy=True)
    payments = db.relationship("Payment", foreign_keys="Payment.student_id", back_populates="student", lazy=True)
    # For Teacher role (attendance recording)
    recorded_attendances = db.relationship("Attendance", foreign_keys="Attendance.recorded_by_teacher_id", back_populates="recorded_by_teacher", lazy=True)
    # For Teacher role (memorization evaluation)
    evaluated_memorizations = db.relationship("MemorizationProgress", foreign_keys="MemorizationProgress.teacher_id_evaluator", back_populates="evaluator_teacher", lazy=True)
    # For Director role (payment recording)
    recorded_payments = db.relationship("Payment", foreign_keys="Payment.recorded_by_director_id", back_populates="recorded_by_director", lazy=True)


    def __init__(self, full_name, email, password, role):
        self.full_name = full_name
        self.email = email
        self.set_password(password)
        self.role = role

    def set_password(self, password):
        self.password_hash = bcrypt.hashpw(password.encode("utf-8"), bcrypt.gensalt()).decode("utf-8")

    def check_password(self, password):
        return bcrypt.checkpw(password.encode("utf-8"), self.password_hash.encode("utf-8"))

    def __repr__(self):
        return f"<User {self.user_id}: {self.full_name} ({self.role.value})>"

