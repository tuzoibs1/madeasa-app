from src.models import db
from datetime import datetime
import enum
from src.models.class_model import Class # Import Class for relationships

class LessonContentType(enum.Enum):
    TEXT = "Text"
    VIDEO = "Video"
    AUDIO = "Audio"
    PDF = "PDF"
    EXTERNAL_LINK = "ExternalLink"

class Lesson(db.Model):
    __tablename__ = "lessons"

    lesson_id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    class_id = db.Column(db.Integer, db.ForeignKey("classes.class_id"), nullable=False)
    title = db.Column(db.String(255), nullable=False)
    content_type = db.Column(db.Enum(LessonContentType), default=LessonContentType.TEXT)
    content_value = db.Column(db.Text, nullable=True)
    lesson_order = db.Column(db.Integer, nullable=True)
    created_at = db.Column(db.TIMESTAMP, default=datetime.utcnow)
    updated_at = db.Column(db.TIMESTAMP, default=datetime.utcnow, onupdate=datetime.utcnow)

    # Relationships
    class_obj = db.relationship("Class", back_populates="lessons")
    quizzes = db.relationship("Quiz", back_populates="lesson", lazy=True, cascade="all, delete-orphan")
    memorization_progress_entries = db.relationship("MemorizationProgress", back_populates="lesson", lazy=True, cascade="all, delete-orphan")

    def __init__(self, class_id, title, content_type=LessonContentType.TEXT, content_value=None, lesson_order=None):
        self.class_id = class_id
        self.title = title
        self.content_type = content_type
        self.content_value = content_value
        self.lesson_order = lesson_order

    def __repr__(self):
        return f"<Lesson {self.lesson_id}: {self.title}>"

