import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { fetchData } from '../utils/api'; // Assuming api.js is in src/utils

const DirectorDashboard = () => {
  const userName = localStorage.getItem('userName') || 'Director';
  const token = localStorage.getItem('token');

  const [summaryStats, setSummaryStats] = useState({ teachers: 0, students: 0, classes: 0 });
  const [recentPayments, setRecentPayments] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    const loadDashboardData = async () => {
      if (!token) {
        setError("User not authenticated. Please login.");
        setLoading(false);
        return;
      }
      setLoading(true);
      setError('');
      try {
        // Fetch summary stats (these would require specific backend endpoints)
        // const teachersData = await fetchData('users/summary?role=Teacher');
        // const studentsData = await fetchData('users/summary?role=Student');
        // const classesData = await fetchData('classes/summary');
        // setSummaryStats({ 
        //   teachers: teachersData?.count || 0, 
        //   students: studentsData?.count || 0, 
        //   classes: classesData?.count || 0 
        // });

        // Fetch recent payments (Director has access to all payments)
        const paymentsData = await fetchData('payments/all'); // Assuming 'payments/all' is the endpoint
        setRecentPayments(paymentsData ? paymentsData.slice(0, 5) : []); // Show top 5 recent

        // Mocking summary stats as backend endpoints for these specific summaries are not yet defined
        setSummaryStats({ teachers: 5, students: 50, classes: 10 });

      } catch (err) {
        console.error("Error fetching director dashboard data:", err);
        setError(err.message || "Failed to load dashboard data.");
      }
      setLoading(false);
    };

    loadDashboardData();
  }, [token]);

  if (loading) {
    return <div className="text-center p-10">Loading dashboard...</div>;
  }

  if (error) {
    return <div className="text-center p-10 text-red-500">Error: {error}</div>;
  }

  return (
    <div className="bg-white p-6 rounded-lg shadow-md">
      <h1 className="text-3xl font-bold text-gray-800 mb-6">Director Dashboard</h1>
      <p className="text-lg text-gray-700 mb-6">
        Welcome, {userName}! This is your central hub for managing the platform.
      </p>

      {/* Summary Stats Section */}
      <section className="mb-8">
        <h2 className="text-2xl font-semibold text-gray-700 mb-4">Platform Overview</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          <div className="bg-blue-100 p-6 rounded-lg shadow text-center">
            <h3 className="text-4xl font-bold text-blue-700">{summaryStats.teachers}</h3>
            <p className="text-sm text-blue-600">Total Teachers</p>
          </div>
          <div className="bg-green-100 p-6 rounded-lg shadow text-center">
            <h3 className="text-4xl font-bold text-green-700">{summaryStats.students}</h3>
            <p className="text-sm text-green-600">Total Students</p>
          </div>
          <div className="bg-yellow-100 p-6 rounded-lg shadow text-center">
            <h3 className="text-4xl font-bold text-yellow-700">{summaryStats.classes}</h3>
            <p className="text-sm text-yellow-600">Total Classes</p>
          </div>
        </div>
      </section>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <div className="bg-sky-100 p-4 rounded-lg shadow">
          <h2 className="text-xl font-semibold text-sky-700 mb-2">Teacher Management</h2>
          <p className="text-sm text-gray-600">View and manage teacher accounts, assign classes.</p>
          <Link to="/director/teachers" className="mt-2 inline-block text-sm text-sky-600 hover:underline">Manage Teachers</Link>
        </div>

        <div className="bg-teal-100 p-4 rounded-lg shadow">
          <h2 className="text-xl font-semibold text-teal-700 mb-2">Class Summaries</h2>
          <p className="text-sm text-gray-600">Oversee all classes, view enrollment numbers and progress.</p>
          <Link to="/director/classes" className="mt-2 inline-block text-sm text-teal-600 hover:underline">View Classes</Link>
        </div>

        <div className="bg-amber-100 p-4 rounded-lg shadow">
          <h2 className="text-xl font-semibold text-amber-700 mb-2">Billing & Payments</h2>
          <p className="text-sm text-gray-600">Track overall payment status and manage billing information.</p>
          <Link to="/director/payments" className="mt-2 inline-block text-sm text-amber-600 hover:underline">Manage Payments</Link>
        </div>

        <div className="bg-purple-100 p-4 rounded-lg shadow">
          <h2 className="text-xl font-semibold text-purple-700 mb-2">Student Overview</h2>
          <p className="text-sm text-gray-600">Get insights into student enrollment and overall platform usage.</p>
           <Link to="/director/students" className="mt-2 inline-block text-sm text-purple-600 hover:underline">View Students</Link>
        </div>

        <div className="bg-indigo-100 p-4 rounded-lg shadow">
          <h2 className="text-xl font-semibold text-indigo-700 mb-2">Platform Settings</h2>
          <p className="text-sm text-gray-600">Configure site-wide settings and announcements.</p>
           <Link to="/director/settings" className="mt-2 inline-block text-sm text-indigo-600 hover:underline">Go to Settings</Link>
        </div>

        <div className="bg-pink-100 p-4 rounded-lg shadow">
          <h2 className="text-xl font-semibold text-pink-700 mb-2">Reports & Analytics</h2>
          <p className="text-sm text-gray-600">Generate reports on various aspects of the platform.</p>
          <Link to="/director/reports" className="mt-2 inline-block text-sm text-pink-600 hover:underline">View Reports</Link>
        </div>
      </div>

      {/* Recent Payments Section */}
      <section className="mt-8">
        <h2 className="text-2xl font-semibold text-gray-700 mb-4">Recent Payments</h2>
        {recentPayments.length > 0 ? (
          <div className="bg-gray-50 p-4 rounded-lg shadow max-h-80 overflow-y-auto">
            <ul className="divide-y divide-gray-200">
              {recentPayments.map(payment => (
                <li key={payment.payment_id} className="py-3">
                  <div className="flex justify-between items-center">
                    <div>
                      <p className="text-sm font-medium text-gray-800">Student: {payment.student_name || `ID ${payment.student_id}`}</p>
                      <p className="text-xs text-gray-500">Amount: ${payment.amount} - Date: {new Date(payment.payment_date).toLocaleDateString()}</p>
                    </div>
                    <span className={`px-2 py-1 text-xs font-semibold rounded-full ${payment.status === 'Paid' ? 'bg-green-200 text-green-800' : 'bg-yellow-200 text-yellow-800'}`}>
                      {payment.status}
                    </span>
                  </div>
                  {payment.description && <p className="text-xs text-gray-500 mt-1">Description: {payment.description}</p>}
                </li>
              ))}
            </ul>
          </div>
        ) : (
          <p className="text-gray-500">No recent payments found.</p>
        )}
      </section>

      <div className="mt-8">
        <h3 className="text-2xl font-semibold text-gray-700 mb-3">Quick Actions</h3>
        <div className="flex space-x-4">
          <button className="bg-blue-500 hover:bg-blue-600 text-white font-medium py-2 px-4 rounded-lg">
            Create New Class
          </button>
          <button className="bg-green-500 hover:bg-green-600 text-white font-medium py-2 px-4 rounded-lg">
            Register New Teacher
          </button>
        </div>
      </div>

    </div>
  );
};

export default DirectorDashboard;

