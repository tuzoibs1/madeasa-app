const API_URL = process.env.REACT_APP_API_URL || "http://localhost:5000/api";

const getAuthHeaders = () => {
  const token = localStorage.getItem("token");
  return {
    "Content-Type": "application/json",
    ...(token && { "Authorization": `Bearer ${token}` }),
  };
};

const handleResponse = async (response) => {
  if (!response.ok) {
    const errorData = await response.json().catch(() => ({ message: response.statusText }));
    throw new Error(errorData.message || "An API error occurred");
  }
  // If response is 204 No Content, there's no JSON to parse
  if (response.status === 204) {
    return null; 
  }
  return response.json();
};

export const loginUser = async (credentials) => {
  const response = await fetch(`${API_URL}/users/login`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify(credentials),
  });
  return handleResponse(response);
};

export const registerUser = async (userData) => {
  const response = await fetch(`${API_URL}/users/register`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify(userData),
  });
  return handleResponse(response);
};

export const fetchUserProfile = async () => {
  const response = await fetch(`${API_URL}/users/profile`, {
    headers: getAuthHeaders(),
  });
  return handleResponse(response);
};

// Example: Fetch lessons for a class
export const fetchLessonsForClass = async (classId) => {
  const response = await fetch(`${API_URL}/lessons/class/${classId}`, {
    headers: getAuthHeaders(),
  });
  return handleResponse(response);
};

// Example: Record attendance
export const recordAttendance = async (attendanceData) => {
  const response = await fetch(`${API_URL}/attendance/check_in_out`, {
    method: "POST",
    headers: getAuthHeaders(),
    body: JSON.stringify(attendanceData),
  });
  return handleResponse(response);
};

// Example: Get student attendance for a class
export const getStudentAttendanceForClass = async (studentId, classId) => {
  const response = await fetch(`${API_URL}/attendance/student/${studentId}/class/${classId}`, {
    headers: getAuthHeaders(),
  });
  return handleResponse(response);
};

// Example: Track memorization progress
export const trackMemorizationProgress = async (progressData) => {
  const response = await fetch(`${API_URL}/memorization/progress`, {
    method: "POST",
    headers: getAuthHeaders(),
    body: JSON.stringify(progressData),
  });
  return handleResponse(response);
};

// Example: Get student's memorization progress
export const getStudentMemorizationProgress = async (studentId) => {
  const response = await fetch(`${API_URL}/memorization/student/${studentId}`, {
    headers: getAuthHeaders(),
  });
  return handleResponse(response);
};

// Add more API utility functions as needed for quizzes, payments, etc.

// Quiz API examples
export const fetchQuizzesForLesson = async (lessonId) => {
  const response = await fetch(`${API_URL}/quizzes/lesson/${lessonId}`, {
    headers: getAuthHeaders(),
  });
  return handleResponse(response);
};

export const fetchQuizWithQuestions = async (quizId) => {
  const response = await fetch(`${API_URL}/quizzes/${quizId}`, {
    headers: getAuthHeaders(),
  });
  return handleResponse(response);
};

export const startOrSubmitQuizAttempt = async (quizId, attemptData) => {
  const response = await fetch(`${API_URL}/quizzes/${quizId}/attempt`, {
    method: "POST",
    headers: getAuthHeaders(),
    body: JSON.stringify(attemptData),
  });
  return handleResponse(response);
};

// Generic fetch function for GET requests
export const fetchData = async (endpoint) => {
  const response = await fetch(`${API_URL}/${endpoint}`, {
    headers: getAuthHeaders(),
  });
  return handleResponse(response);
};

// Generic function for POST requests
export const postData = async (endpoint, data) => {
  const response = await fetch(`${API_URL}/${endpoint}`, {
    method: "POST",
    headers: getAuthHeaders(),
    body: JSON.stringify(data),
  });
  return handleResponse(response);
};

// Generic function for PUT requests
export const putData = async (endpoint, data) => {
  const response = await fetch(`${API_URL}/${endpoint}`, {
    method: "PUT",
    headers: getAuthHeaders(),
    body: JSON.stringify(data),
  });
  return handleResponse(response);
};

// Generic function for DELETE requests
export const deleteData = async (endpoint) => {
  const response = await fetch(`${API_URL}/${endpoint}`, {
    method: "DELETE",
    headers: getAuthHeaders(),
  });
  return handleResponse(response);
};

