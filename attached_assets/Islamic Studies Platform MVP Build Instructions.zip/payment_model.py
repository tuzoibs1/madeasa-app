from src.models import db
from datetime import datetime
import enum
from src.models.user_model import User # Import User for relationships
from src.models.class_model import Class # Import Class for relationships

class PaymentStatus(enum.Enum):
    PENDING = "Pending"
    PAID = "Paid"
    FAILED = "Failed"
    REFUNDED = "Refunded"

class Payment(db.Model):
    __tablename__ = "payments"

    payment_id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    student_id = db.Column(db.Integer, db.ForeignKey("users.user_id"), nullable=False)
    class_id = db.Column(db.Integer, db.ForeignKey("classes.class_id"), nullable=True)
    amount = db.Column(db.Numeric(10,2), nullable=False)
    payment_date = db.Column(db.Date, nullable=False, default=datetime.utcnow)
    payment_method = db.Column(db.String(50), default="Manual")
    transaction_id = db.Column(db.String(255), nullable=True)
    status = db.Column(db.Enum(PaymentStatus), default=PaymentStatus.PENDING)
    description = db.Column(db.Text, nullable=True)
    recorded_by_director_id = db.Column(db.Integer, db.ForeignKey("users.user_id"), nullable=True)
    created_at = db.Column(db.TIMESTAMP, default=datetime.utcnow)
    updated_at = db.Column(db.TIMESTAMP, default=datetime.utcnow, onupdate=datetime.utcnow)

    # Relationships
    student = db.relationship("User", foreign_keys=[student_id], back_populates="payments")
    class_obj = db.relationship("Class", back_populates="payments")
    recorded_by_director = db.relationship("User", foreign_keys=[recorded_by_director_id], back_populates="recorded_payments")

    def __init__(self, student_id, amount, payment_date, class_id=None, payment_method="Manual", transaction_id=None, status=PaymentStatus.PENDING, description=None, recorded_by_director_id=None):
        self.student_id = student_id
        self.class_id = class_id
        self.amount = amount
        self.payment_date = payment_date
        self.payment_method = payment_method
        self.transaction_id = transaction_id
        self.status = status
        self.description = description
        self.recorded_by_director_id = recorded_by_director_id

    def __repr__(self):
        return f"<Payment {self.payment_id}: Student {self.student_id} - Amount {self.amount} ({self.status.value})>"

