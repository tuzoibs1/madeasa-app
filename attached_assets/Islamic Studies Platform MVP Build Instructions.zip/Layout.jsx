import React from 'react';
import { Link, useNavigate } from 'react-router-dom';

const Layout = ({ children }) => {
  const navigate = useNavigate();
  const isAuthenticated = !!localStorage.getItem('token');
  const userRole = localStorage.getItem('role');
  const userName = localStorage.getItem('userName'); // Assuming userName is stored

  const handleLogout = () => {
    localStorage.removeItem('token');
    localStorage.removeItem('role');
    localStorage.removeItem('userId');
    localStorage.removeItem('userName');
    navigate('/login');
  };

  return (
    <div className="min-h-screen flex flex-col bg-gray-100">
      <header className="bg-blue-600 text-white p-4 shadow-md">
        <div className="container mx-auto flex justify-between items-center">
          <Link to="/" className="text-2xl font-bold hover:text-blue-200">
            Islamic Studies Platform
          </Link>
          <nav className="space-x-4">
            {isAuthenticated ? (
              <>
                <span className="text-sm">Welcome, {userName || userRole}!</span>
                {userRole === 'Director' && <Link to="/director" className="hover:text-blue-200">Director Dashboard</Link>}
                {userRole === 'Teacher' && <Link to="/teacher" className="hover:text-blue-200">Teacher Dashboard</Link>}
                {userRole === 'Student' && <Link to="/student" className="hover:text-blue-200">Student Dashboard</Link>}
                <button 
                  onClick={handleLogout} 
                  className="bg-red-500 hover:bg-red-700 text-white font-bold py-2 px-4 rounded text-sm"
                >
                  Logout
                </button>
              </>
            ) : (
              <>
                <Link to="/login" className="hover:text-blue-200">Login</Link>
                <Link to="/register" className="hover:text-blue-200">Register</Link>
              </>
            )}
          </nav>
        </div>
      </header>
      <main className="flex-grow container mx-auto p-4 md:p-6 lg:p-8">
        {children}
      </main>
      <footer className="bg-gray-800 text-white text-center p-4 mt-auto">
        <p>&copy; {new Date().getFullYear()} Islamic Studies Platform. All rights reserved.</p>
      </footer>
    </div>
  );
};

export default Layout;

