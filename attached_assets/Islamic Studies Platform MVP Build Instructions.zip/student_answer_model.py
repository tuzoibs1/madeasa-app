from src.models import db
from datetime import datetime
from src.models.quiz_attempt_model import QuizAttempt # Import QuizAttempt for relationships
from src.models.question_model import Question # Import Question for relationships

class StudentAnswer(db.Model):
    __tablename__ = "student_answers"

    student_answer_id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    attempt_id = db.Column(db.Integer, db.ForeignKey("quiz_attempts.attempt_id"), nullable=False)
    question_id = db.Column(db.Integer, db.ForeignKey("questions.question_id"), nullable=False)
    answer_text = db.Column(db.Text, nullable=True)
    is_correct = db.Column(db.Boolean, nullable=True)
    points_awarded = db.Column(db.Integer, nullable=True)
    created_at = db.Column(db.TIMESTAMP, default=datetime.utcnow)
    updated_at = db.Column(db.TIMESTAMP, default=datetime.utcnow, onupdate=datetime.utcnow)

    # Relationships
    quiz_attempt = db.relationship("QuizAttempt", back_populates="student_answers")
    question = db.relationship("Question", back_populates="student_answers")

    def __init__(self, attempt_id, question_id, answer_text=None, is_correct=None, points_awarded=None):
        self.attempt_id = attempt_id
        self.question_id = question_id
        self.answer_text = answer_text
        self.is_correct = is_correct
        self.points_awarded = points_awarded

    def __repr__(self):
        return f"<StudentAnswer {self.student_answer_id}: Attempt {self.attempt_id} for Question {self.question_id}>"

