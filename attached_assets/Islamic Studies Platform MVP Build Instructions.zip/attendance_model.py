from src.models import db
from datetime import datetime
import enum
from src.models.user_model import User # Import User for relationships
from src.models.enrollment_model import Enrollment # Import Enrollment for relationships

class AttendanceStatus(enum.Enum):
    PRESENT = "Present"
    ABSENT = "Absent"
    LATE = "Late"
    EXCUSED = "Excused"

class Attendance(db.Model):
    __tablename__ = "attendance"

    attendance_id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    enrollment_id = db.Column(db.Integer, db.ForeignKey("enrollment.enrollment_id"), nullable=False)
    session_date = db.Column(db.Date, nullable=False, default=datetime.utcnow)
    status = db.Column(db.Enum(AttendanceStatus), nullable=False)
    notes = db.Column(db.Text, nullable=True)
    recorded_by_teacher_id = db.Column(db.Integer, db.ForeignKey("users.user_id"), nullable=True)
    created_at = db.Column(db.TIMESTAMP, default=datetime.utcnow)
    updated_at = db.Column(db.TIMESTAMP, default=datetime.utcnow, onupdate=datetime.utcnow)

    # Relationships
    enrollment = db.relationship("Enrollment", back_populates="attendances")
    recorded_by_teacher = db.relationship("User", foreign_keys=[recorded_by_teacher_id], back_populates="recorded_attendances")

    __table_args__ = (db.UniqueConstraint("enrollment_id", "session_date", name="uq_enrollment_session_attendance"),)

    def __init__(self, enrollment_id, session_date, status, notes=None, recorded_by_teacher_id=None):
        self.enrollment_id = enrollment_id
        self.session_date = session_date
        self.status = status
        self.notes = notes
        self.recorded_by_teacher_id = recorded_by_teacher_id

    def __repr__(self):
        return f"<Attendance {self.attendance_id}: Enrollment {self.enrollment_id} on {self.session_date} - {self.status.value}>"

