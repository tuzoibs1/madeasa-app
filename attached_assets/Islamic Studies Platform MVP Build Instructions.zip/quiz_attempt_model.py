from src.models import db
from datetime import datetime
import enum
from src.models.user_model import User # Import User for relationships
from src.models.quiz_model import Quiz # Import Quiz for relationships

class QuizAttemptStatus(enum.Enum):
    IN_PROGRESS = "InProgress"
    COMPLETED = "Completed"
    GRADED = "Graded"

class QuizAttempt(db.Model):
    __tablename__ = "quiz_attempts"

    attempt_id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    quiz_id = db.Column(db.Integer, db.ForeignKey("quizzes.quiz_id"), nullable=False)
    student_id = db.Column(db.Integer, db.ForeignKey("users.user_id"), nullable=False)
    start_time = db.Column(db.TIMESTAMP, nullable=True, default=datetime.utcnow)
    end_time = db.Column(db.TIMESTAMP, nullable=True)
    score = db.Column(db.Numeric(5,2), nullable=True)
    status = db.Column(db.Enum(QuizAttemptStatus), default=QuizAttemptStatus.IN_PROGRESS)
    created_at = db.Column(db.TIMESTAMP, default=datetime.utcnow)
    updated_at = db.Column(db.TIMESTAMP, default=datetime.utcnow, onupdate=datetime.utcnow)

    # Relationships
    quiz = db.relationship("Quiz", back_populates="quiz_attempts")
    student = db.relationship("User", back_populates="quiz_attempts")
    student_answers = db.relationship("StudentAnswer", back_populates="quiz_attempt", lazy=True, cascade="all, delete-orphan")

    def __init__(self, quiz_id, student_id, start_time=None, status=QuizAttemptStatus.IN_PROGRESS):
        self.quiz_id = quiz_id
        self.student_id = student_id
        self.start_time = start_time if start_time else datetime.utcnow()
        self.status = status

    def __repr__(self):
        return f"<QuizAttempt {self.attempt_id}: Student {self.student_id} for Quiz {self.quiz_id}>"

