from src.models import db
from datetime import datetime
from src.models.user_model import User # Import User for relationships

class Class(db.Model):
    __tablename__ = "classes"

    class_id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    class_name = db.Column(db.String(255), nullable=False)
    description = db.Column(db.Text, nullable=True)
    teacher_id = db.Column(db.Integer, db.ForeignKey("users.user_id"), nullable=True)
    created_at = db.Column(db.TIMESTAMP, default=datetime.utcnow)
    updated_at = db.Column(db.TIMESTAMP, default=datetime.utcnow, onupdate=datetime.utcnow)

    # Relationships
    teacher = db.relationship("User", foreign_keys=[teacher_id], back_populates="taught_classes")
    enrollments = db.relationship("Enrollment", back_populates="class_obj", lazy=True, cascade="all, delete-orphan")
    lessons = db.relationship("Lesson", back_populates="class_obj", lazy=True, cascade="all, delete-orphan")
    payments = db.relationship("Payment", back_populates="class_obj", lazy=True)

    def __init__(self, class_name, description=None, teacher_id=None):
        self.class_name = class_name
        self.description = description
        self.teacher_id = teacher_id

    def __repr__(self):
        return f"<Class {self.class_id}: {self.class_name}>"

