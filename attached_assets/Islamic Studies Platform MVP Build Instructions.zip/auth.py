import os
import datetime
import jwt
from functools import wraps
from flask import request, jsonify
from src.models.user_model import User, UserRole

# Configuration for JWT
SECRET_KEY = os.getenv("SECRET_KEY", "your_default_secret_key") # Ensure to set this in environment variables
TOKEN_EXPIRATION_HOURS = 24

def generate_token(user_id, role):
    """Generates an authentication token."""
    try:
        payload = {
            "exp": datetime.datetime.utcnow() + datetime.timedelta(hours=TOKEN_EXPIRATION_HOURS),
            "iat": datetime.datetime.utcnow(),
            "sub": user_id,
            "role": role.value # Store role value (string) in token
        }
        return jwt.encode(
            payload,
            SECRET_KEY,
            algorithm="HS256"
        )
    except Exception as e:
        return str(e)

def token_required(f):
    """Decorator to protect routes with token authentication."""
    @wraps(f)
    def decorated(*args, **kwargs):
        token = None
        if "Authorization" in request.headers:
            auth_header = request.headers["Authorization"]
            if auth_header.startswith("Bearer "):
                token = auth_header.split(" ")[1]

        if not token:
            return jsonify({"message": "Token is missing!"}), 401

        try:
            data = jwt.decode(token, SECRET_KEY, algorithms=["HS256"])
            current_user = User.query.filter_by(user_id=data["sub"]).first()
            if not current_user:
                return jsonify({"message": "User not found!"}), 401
            # Add user and role to request context or pass as argument
            request.current_user_id = current_user.user_id
            request.current_user_role = UserRole(data["role"]) # Convert string back to Enum

        except jwt.ExpiredSignatureError:
            return jsonify({"message": "Token has expired!"}), 401
        except jwt.InvalidTokenError:
            return jsonify({"message": "Token is invalid!"}), 401
        except Exception as e:
            return jsonify({"message": f"Token processing error: {str(e)}"}), 500

        return f(current_user, *args, **kwargs) # Pass current_user to the decorated function
    return decorated

def role_required(roles):
    """Decorator to restrict access based on user roles."""
    if not isinstance(roles, list):
        roles = [roles]

    def decorator(f):
        @wraps(f)
        def decorated_function(*args, **kwargs):
            if not hasattr(request, "current_user_role") or request.current_user_role not in roles:
                return jsonify({"message": "Unauthorized! Insufficient role permissions."}), 403
            return f(*args, **kwargs)
        return decorated_function
    return decorator

