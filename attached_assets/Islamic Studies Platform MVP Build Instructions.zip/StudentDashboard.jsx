import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { 
    fetchData, // Generic fetch for student's enrolled classes, attendance, etc.
    getStudentMemorizationProgress, 
    fetchQuizzesForLesson // This might be part of a course detail view
} from '../utils/api'; // Assuming api.js is in src/utils

const StudentDashboard = () => {
  const userName = localStorage.getItem('userName') || 'Student';
  const token = localStorage.getItem('token');
  const userId = localStorage.getItem('userId');

  const [myCourses, setMyCourses] = useState([]);
  const [myAttendance, setMyAttendance] = useState([]);
  const [memorizationProgress, setMemorizationProgress] = useState([]);
  const [upcomingQuizzes, setUpcomingQuizzes] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    const loadDashboardData = async () => {
      if (!userId || !token) {
        setError("User not authenticated. Please login.");
        setLoading(false);
        return;
      }
      setLoading(true);
      setError('');
      try {
        // Fetch enrolled courses (assuming an endpoint like /api/users/{userId}/enrollments or similar)
        // For MVP, let's assume a generic endpoint or a more specific one if available.
        // This part needs a backend endpoint that returns courses for a student with teacher name and progress (which might be complex for one call)
        // Using a placeholder or a simplified call for now.
        // const enrolledCoursesData = await fetchData(`enrollments/student/${userId}`); // Placeholder endpoint
        // setMyCourses(enrolledCoursesData || []);

        // Fetch memorization progress
        const memorizationData = await getStudentMemorizationProgress(userId);
        setMemorizationProgress(memorizationData || []);

        // Fetch attendance (e.g., recent attendance for all enrolled classes)
        // This would likely require a dedicated endpoint or iterating through enrolled classes
        // const attendanceData = await fetchData(`attendance/student/${userId}/summary`); // Placeholder
        // setMyAttendance(attendanceData || []);
        
        // Fetch upcoming quizzes (this is also complex, might need to iterate courses/lessons)
        // const quizzesData = await fetchData(`quizzes/student/${userId}/upcoming`); // Placeholder
        // setUpcomingQuizzes(quizzesData || []);

        // Using mock data for parts not yet connected to avoid breaking UI
        setMyCourses([
          { id: 1, class_id: 101, name: 'Quranic Studies 101 (API Placeholder)', teacher: 'Dr. Ahmed (API)', progress: '70%', nextLesson: 'Surah Al-Mulk Recitation (API)' },
        ]);
        setMyAttendance([
          { date: '2024-05-15', class_name: 'Quranic Studies 101', status: 'Present' },
        ]);
        setUpcomingQuizzes([
          { id: 1, name: 'Quiz on Surah Yasin (API)', class_name: 'Quranic Studies 101', due_date: '2024-05-25' },
        ]);

      } catch (err) {
        console.error("Error fetching student dashboard data:", err);
        setError(err.message || "Failed to load dashboard data.");
      }
      setLoading(false);
    };

    loadDashboardData();
  }, [userId, token]);

  if (loading) {
    return <div className="text-center p-10">Loading dashboard...</div>;
  }

  if (error) {
    return <div className="text-center p-10 text-red-500">Error: {error}</div>;
  }

  return (
    <div className="bg-white p-6 rounded-lg shadow-md">
      <h1 className="text-3xl font-bold text-gray-800 mb-6">Student Dashboard</h1>
      <p className="text-lg text-gray-700 mb-6">
        Welcome, {userName}! Here is an overview of your learning journey.
      </p>

      {/* My Courses Section */}
      <section className="mb-8">
        <h2 className="text-2xl font-semibold text-gray-700 mb-4">My Enrolled Courses</h2>
        {myCourses.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {myCourses.map(course => (
              <div key={course.id || course.class_id} className="bg-blue-50 p-4 rounded-lg shadow border border-blue-200">
                <h3 className="text-xl font-medium text-blue-700">{course.name}</h3>
                <p className="text-sm text-gray-600">Teacher: {course.teacher}</p>
                <p className="text-sm text-gray-600">Progress: {course.progress}</p>
                <p className="text-sm text-gray-600">Next Lesson: {course.nextLesson}</p>
                <Link to={`/student/class/${course.class_id}`} className="mt-2 inline-block bg-blue-500 hover:bg-blue-600 text-white text-sm py-1 px-3 rounded">
                  Go to Course
                </Link>
              </div>
            ))}
          </div>
        ) : (
          <p className="text-gray-500">You are not currently enrolled in any courses.</p>
        )}
      </section>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
        {/* Attendance Summary */}
        <section>
          <h2 className="text-xl font-semibold text-gray-700 mb-3">Attendance Summary</h2>
          <div className="bg-green-50 p-4 rounded-lg shadow max-h-60 overflow-y-auto">
            {myAttendance.length > 0 ? (
              <ul className="space-y-2">
                {myAttendance.map((att, index) => (
                  <li key={index} className="text-sm text-gray-700 flex justify-between p-2 bg-white rounded border border-green-200">
                    <span>{att.date} - {att.class_name}</span>
                    <span className={`font-medium ${att.status === 'Present' ? 'text-green-600' : 'text-red-600'}`}>{att.status}</span>
                  </li>
                ))}
              </ul>
            ) : (
              <p className="text-gray-500">No attendance records found.</p>
            )}
          </div>
        </section>

        {/* Memorization Progress */}
        <section>
          <h2 className="text-xl font-semibold text-gray-700 mb-3">Memorization Progress</h2>
          <div className="bg-yellow-50 p-4 rounded-lg shadow max-h-60 overflow-y-auto">
            {memorizationProgress.length > 0 ? (
              <ul className="space-y-2">
                {memorizationProgress.map((mem) => (
                  <li key={mem.progress_id} className="text-sm text-gray-700 p-2 bg-white rounded border border-yellow-200">
                    <h4 className="font-medium text-yellow-700">Lesson: {mem.lesson_title || `Lesson ID ${mem.lesson_id}`}</h4>
                    {mem.surah_juz_aya_start && <p>Portion: {mem.surah_juz_aya_start} - {mem.surah_juz_aya_end}</p>}
                    <p>Status: {mem.status} {mem.accuracy_score ? `- Accuracy: ${mem.accuracy_score}%` : ''}</p>
                  </li>
                ))}
              </ul>
            ) : (
              <p className="text-gray-500">No memorization progress tracked yet.</p>
            )}
          </div>
        </section>
      </div>

      {/* Upcoming Quizzes Section */}
      <section>
        <h2 className="text-2xl font-semibold text-gray-700 mb-4">Upcoming Quizzes</h2>
        {upcomingQuizzes.length > 0 ? (
          <div className="bg-purple-50 p-4 rounded-lg shadow">
            <ul className="space-y-3">
              {upcomingQuizzes.map(quiz => (
                <li key={quiz.id} className="p-3 bg-white rounded-md shadow-sm border border-purple-200">
                  <h3 className="font-medium text-purple-700">{quiz.name}</h3>
                  <p className="text-sm text-gray-600">Course: {quiz.class_name}</p>
                  <p className="text-sm text-gray-600">Due Date: {quiz.due_date}</p>
                  <Link to={`/student/quiz/${quiz.id}`} className="mt-2 inline-block bg-purple-500 hover:bg-purple-600 text-white text-sm py-1 px-3 rounded">
                    View Quiz
                  </Link>
                </li>
              ))}
            </ul>
          </div>
        ) : (
          <p className="text-gray-500">No upcoming quizzes.</p>
        )}
      </section>

    </div>
  );
};

export default StudentDashboard;

