# Permanent Deployment - Islamic Studies Platform MVP

- [x] Clarify permanent deployment preferences with the user.
- [x] Prepare backend for permanent deployment (Railway). # Procfile created, requirements.txt updated with gunicorn, psycopg2-binary, Flask-CORS.
- [x] Prepare frontend for permanent deployment (Vercel). # Frontend build scripts verified (Vite), .env.example for REACT_APP_API_URL is in place. Vercel will auto-detect and build.
- [ ] Configure domains and environment variables for production. # In Progress