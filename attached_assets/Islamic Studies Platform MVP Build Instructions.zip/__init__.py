# Initializes the models package
from flask_sqlalchemy import SQLAlchemy

db = SQLAlchemy()

