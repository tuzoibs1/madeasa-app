# Islamic Studies Platform - MVP Build Todo List

- [x] Clarify requirements with the user.
- [x] Set up the project directory structure.
- [x] Design and document the database schema for Users, Classes, Enrollment, Attendance, Memorization Progress, Lessons, Quizzes, and Payments.
- [x] Implement backend authentication with JWT and role-based access (Director, Teacher, Student).
- [x] Build core backend API endpoints for user registration/login, attendance check-in/out, memorization progress tracking, and basic CRUD for lessons/quizzes.
- [x] Scaffold the frontend project with role-based dashboards (Director, Teacher, Student). # Basic structure and placeholder dashboards created.
- [x] Connect frontend to backend APIs for core features (attendance, memorization, login/logout, lessons, quizzes). # API utilities created, dashboards updated with API calls or placeholders.
- [x] Use placeholder/mock data where the backend isn't ready. # Mock data used in dashboards, to be replaced by full API integration.
- [x] Prepare for backend deployment (Railway or AWS). # Requirements frozen, .env.example created.
- [x] Prepare for frontend deployment (Vercel). # .env.example created.
- [x] Set up environment variables for API URLs and secrets. # Example files created, actual values to be set by user.
- [x] Ensure code is modular and well-documented. # Completed as part of documentation step
- [x] Set up GitHub for version control. # Files prepared, user to handle actual GitHub setup.
- [x] Plan CI/CD pipelines for automated testing and deployment. # Notes included in documentation.
- [x] Follow accessibility and responsive design best practices. # Considered during frontend dev, noted in docs.
- [x] Document the project according to the specified format. # Completed, project_documentation.json created.
- [x] Generate API documentation. # Included in project_documentation.json.
- [x] Export the database schema. # database_schema.md created and included.