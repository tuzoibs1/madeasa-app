from src.models import db
from datetime import datetime
import enum
import json # For options JSON field
from src.models.quiz_model import Quiz # Import Quiz for relationships

class QuestionType(enum.Enum):
    MULTIPLE_CHOICE = "MultipleChoice"
    TRUE_FALSE = "TrueFalse"
    SHORT_ANSWER = "ShortAnswer"

class Question(db.Model):
    __tablename__ = "questions"

    question_id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    quiz_id = db.Column(db.Integer, db.ForeignKey("quizzes.quiz_id"), nullable=False)
    question_text = db.Column(db.Text, nullable=False)
    question_type = db.Column(db.Enum(QuestionType), nullable=False)
    options = db.Column(db.JSON, nullable=True)  # Store options as JSON, e.g., {"A": "Opt1", "B": "Opt2", "correct": "A"}
    correct_answer_text = db.Column(db.Text, nullable=True) # For ShortAnswer type
    points = db.Column(db.Integer, default=1)
    created_at = db.Column(db.TIMESTAMP, default=datetime.utcnow)
    updated_at = db.Column(db.TIMESTAMP, default=datetime.utcnow, onupdate=datetime.utcnow)

    # Relationships
    quiz = db.relationship("Quiz", back_populates="questions")
    student_answers = db.relationship("StudentAnswer", back_populates="question", lazy=True, cascade="all, delete-orphan")

    def __init__(self, quiz_id, question_text, question_type, options=None, correct_answer_text=None, points=1):
        self.quiz_id = quiz_id
        self.question_text = question_text
        self.question_type = question_type
        if self.question_type == QuestionType.MULTIPLE_CHOICE or self.question_type == QuestionType.TRUE_FALSE:
            if not isinstance(options, dict) or not all(isinstance(k, str) for k in options.keys()):
                raise ValueError("Options must be a dictionary with string keys for MultipleChoice/TrueFalse questions.")
            if "correct" not in options and self.question_type == QuestionType.MULTIPLE_CHOICE:
                 raise ValueError("Correct answer key 'correct' missing in options for MultipleChoice question.")
        self.options = options
        self.correct_answer_text = correct_answer_text
        self.points = points

    def __repr__(self):
        return f"<Question {self.question_id}: {self.question_text[:50]}... ({self.question_type.value})>"

