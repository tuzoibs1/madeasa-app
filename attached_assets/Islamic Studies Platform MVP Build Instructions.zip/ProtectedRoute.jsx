import React from 'react';
import { Navigate, useLocation } from 'react-router-dom';

const ProtectedRoute = ({ children, roles }) => {
  const location = useLocation();
  const isAuthenticated = !!localStorage.getItem('token');
  const userRole = localStorage.getItem('role');

  if (!isAuthenticated) {
    // Redirect them to the /login page, but save the current location they were
    // trying to go to when they were redirected. This allows us to send them
    // along to that page after they login, which is a nicer user experience
    // than dropping them off on the home page.
    return <Navigate to="/login" state={{ from: location }} replace />;
  }

  if (roles && roles.length > 0 && !roles.includes(userRole)) {
    // If user's role is not in the allowed roles, redirect to a generic page or login
    // Or, ideally, to a specific 'Unauthorized' page
    // For MVP, redirecting to login or a simple message page might suffice.
    // Or, if they are logged in but wrong role, maybe to their own dashboard or home.
    
    // Determine where to redirect if role is not authorized
    let redirectPath = "/login"; // Default fallback
    if (userRole === 'Director') redirectPath = "/director";
    else if (userRole === 'Teacher') redirectPath = "/teacher";
    else if (userRole === 'Student') redirectPath = "/student";
    
    // Prevent infinite redirect loops if they are already on their own dashboard
    if (location.pathname === redirectPath) {
        // If they are already on their correct dashboard but somehow tried to access an unauthorized route that redirects here,
        // it might be better to show an 'Unauthorized' component within their current dashboard layout.
        // For now, just let them stay if they are already on their correct dashboard.
        // This case should ideally be handled by not showing links to unauthorized pages.
        return children; 
    }

    return <Navigate to={redirectPath} state={{ from: location }} replace />;
  }

  return children;
};

export default ProtectedRoute;

