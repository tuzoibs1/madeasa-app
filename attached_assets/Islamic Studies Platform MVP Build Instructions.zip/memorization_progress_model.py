from src.models import db
from datetime import datetime
import enum
from src.models.user_model import User # Import User for relationships
from src.models.lesson_model import Lesson # Import Lesson for relationships

class MemorizationStatus(enum.Enum):
    NOT_STARTED = "Not Started"
    IN_PROGRESS = "In Progress"
    MEMORIZED = "Memorized"
    REVISED = "Revised"

class MemorizationProgress(db.Model):
    __tablename__ = "memorization_progress"

    progress_id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    student_id = db.Column(db.Integer, db.ForeignKey("users.user_id"), nullable=False)
    lesson_id = db.Column(db.Integer, db.ForeignKey("lessons.lesson_id"), nullable=False)
    surah_juz_aya_start = db.Column(db.String(100), nullable=True)
    surah_juz_aya_end = db.Column(db.String(100), nullable=True)
    status = db.Column(db.Enum(MemorizationStatus), default=MemorizationStatus.NOT_STARTED)
    last_tested_date = db.Column(db.Date, nullable=True)
    accuracy_score = db.Column(db.Numeric(5,2), nullable=True)
    notes = db.Column(db.Text, nullable=True)
    teacher_id_evaluator = db.Column(db.Integer, db.ForeignKey("users.user_id"), nullable=True)
    created_at = db.Column(db.TIMESTAMP, default=datetime.utcnow)
    updated_at = db.Column(db.TIMESTAMP, default=datetime.utcnow, onupdate=datetime.utcnow)

    # Relationships
    student = db.relationship("User", foreign_keys=[student_id], back_populates="memorization_progress")
    lesson = db.relationship("Lesson", back_populates="memorization_progress_entries")
    evaluator_teacher = db.relationship("User", foreign_keys=[teacher_id_evaluator], back_populates="evaluated_memorizations")

    def __init__(self, student_id, lesson_id, surah_juz_aya_start=None, surah_juz_aya_end=None, status=MemorizationStatus.NOT_STARTED, last_tested_date=None, accuracy_score=None, notes=None, teacher_id_evaluator=None):
        self.student_id = student_id
        self.lesson_id = lesson_id
        self.surah_juz_aya_start = surah_juz_aya_start
        self.surah_juz_aya_end = surah_juz_aya_end
        self.status = status
        self.last_tested_date = last_tested_date
        self.accuracy_score = accuracy_score
        self.notes = notes
        self.teacher_id_evaluator = teacher_id_evaluator

    def __repr__(self):
        return f"<MemorizationProgress {self.progress_id}: Student {self.student_id} for Lesson {self.lesson_id}>"

