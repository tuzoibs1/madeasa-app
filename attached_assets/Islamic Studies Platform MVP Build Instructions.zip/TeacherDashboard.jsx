import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { fetchData, getStudentAttendanceForClass } from '../utils/api'; // Assuming api.js is in src/utils

const TeacherDashboard = () => {
  const userName = localStorage.getItem('userName') || 'Teacher';
  const token = localStorage.getItem('token');
  const teacherId = localStorage.getItem('userId');

  const [myClasses, setMyClasses] = useState([]);
  const [recentActivity, setRecentActivity] = useState([]); // This might be harder to get from a single API call
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    const loadDashboardData = async () => {
      if (!teacherId || !token) {
        setError("User not authenticated. Please login.");
        setLoading(false);
        return;
      }
      setLoading(true);
      setError('');
      try {
        // Fetch classes taught by this teacher
        // Assuming an endpoint like /api/classes?teacher_id={teacherId}
        // The create_flask_app template doesn't have a direct /api/classes endpoint yet.
        // We'll need to add one or use a placeholder.
        // For now, using a placeholder as the backend doesn't have a direct route for this.
        // const classesData = await fetchData(`classes/teacher/${teacherId}`); // Placeholder
        // setMyClasses(classesData || []);
        
        // Mocking classes as the backend endpoint is not yet defined for this specific query
        setMyClasses([
            { class_id: 1, class_name: 'Quranic Studies 101 (API Placeholder)', studentCount: 15, progress: '75%' },
            { class_id: 2, class_name: 'Hadith Analysis (API Placeholder)', studentCount: 10, progress: '60%' },
        ]);

        // Fetch recent activity (e.g., new enrollments, quiz submissions for students in their classes)
        // This is complex and would likely require multiple API calls or a dedicated backend endpoint.
        // For MVP, this might be a simplified list or placeholder.
        setRecentActivity([
            { id: 1, type: 'New Enrollment (API)', student: 'Aisha Khan', class_name: 'Quranic Studies 101', date: '2024-05-13' },
            { id: 2, type: 'Quiz Submitted (API)', student: 'Omar Ali', quiz_name: 'Surah Al-Fatiha Quiz', date: '2024-05-12' },
        ]);

      } catch (err) {
        console.error("Error fetching teacher dashboard data:", err);
        setError(err.message || "Failed to load dashboard data.");
      }
      setLoading(false);
    };

    loadDashboardData();
  }, [teacherId, token]);

  if (loading) {
    return <div className="text-center p-10">Loading dashboard...</div>;
  }

  if (error) {
    return <div className="text-center p-10 text-red-500">Error: {error}</div>;
  }

  return (
    <div className="bg-white p-6 rounded-lg shadow-md">
      <h1 className="text-3xl font-bold text-gray-800 mb-6">Teacher Dashboard</h1>
      <p className="text-lg text-gray-700 mb-4">
        Welcome, {userName}! Manage your classes, students, and educational content here.
      </p>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
        {/* My Classes Section */}
        <div className="bg-blue-50 p-4 rounded-lg shadow">
          <h2 className="text-xl font-semibold text-blue-700 mb-3">My Classes</h2>
          {myClasses.length > 0 ? (
            <ul className="space-y-3">
              {myClasses.map(cls => (
                <li key={cls.class_id} className="p-3 bg-white rounded-md shadow-sm border border-blue-200">
                  <h3 className="font-medium text-blue-600">{cls.class_name}</h3>
                  <p className="text-sm text-gray-600">Students: {cls.studentCount}</p>
                  <p className="text-sm text-gray-600">Overall Progress: {cls.progress}</p>
                  <Link to={`/teacher/class/${cls.class_id}`} className="mt-1 inline-block text-sm text-blue-500 hover:underline">
                    Manage Class
                  </Link>
                </li>
              ))}
            </ul>
          ) : (
            <p className="text-sm text-gray-500">You are not currently assigned to any classes.</p>
          )}
        </div>

        {/* Quick Actions Section */}
        <div className="bg-green-50 p-4 rounded-lg shadow">
          <h2 className="text-xl font-semibold text-green-700 mb-3">Quick Actions</h2>
          <div className="space-y-3">
            <Link to="/teacher/attendance" className="block w-full text-center bg-green-500 hover:bg-green-600 text-white font-medium py-2 px-4 rounded-lg text-sm">
              Manage Attendance
            </Link>
            <Link to="/teacher/progress" className="block w-full text-center bg-green-500 hover:bg-green-600 text-white font-medium py-2 px-4 rounded-lg text-sm">
              Track Student Progress
            </Link>
            <Link to="/teacher/lessons/edit" className="block w-full text-center bg-green-500 hover:bg-green-600 text-white font-medium py-2 px-4 rounded-lg text-sm">
              Edit Syllabus / Add Lesson
            </Link>
            <Link to="/teacher/quizzes/create" className="block w-full text-center bg-green-500 hover:bg-green-600 text-white font-medium py-2 px-4 rounded-lg text-sm">
              Create Quiz
            </Link>
          </div>
        </div>
      </div>

      {/* Recent Activity Section */}
      <div className="bg-gray-50 p-4 rounded-lg shadow">
        <h2 className="text-xl font-semibold text-gray-700 mb-3">Recent Activity</h2>
        {recentActivity.length > 0 ? (
          <ul className="space-y-2">
            {recentActivity.map(activity => (
              <li key={activity.id} className="text-sm text-gray-600 p-2 bg-white rounded-md border border-gray-200">
                <span className={`font-medium ${activity.type.includes('Enrollment') ? 'text-green-600' : 'text-blue-600'}`}>{activity.type}:</span> {activity.student} - {activity.class_name || activity.quiz_name} ({activity.date})
              </li>
            ))}
          </ul>
        ) : (
          <p className="text-sm text-gray-500">No recent activity to display.</p>
        )}
      </div>
    </div>
  );
};

export default TeacherDashboard;

