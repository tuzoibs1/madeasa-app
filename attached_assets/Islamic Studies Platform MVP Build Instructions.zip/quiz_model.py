from src.models import db
from datetime import datetime
from src.models.lesson_model import Lesson # Import Lesson for relationships

class Quiz(db.Model):
    __tablename__ = "quizzes"

    quiz_id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    lesson_id = db.Column(db.Integer, db.ForeignKey("lessons.lesson_id"), nullable=False)
    title = db.Column(db.String(255), nullable=False)
    description = db.Column(db.Text, nullable=True)
    time_limit_minutes = db.Column(db.Integer, nullable=True)
    created_at = db.Column(db.TIMESTAMP, default=datetime.utcnow)
    updated_at = db.Column(db.TIMESTAMP, default=datetime.utcnow, onupdate=datetime.utcnow)

    # Relationships
    lesson = db.relationship("Lesson", back_populates="quizzes")
    questions = db.relationship("Question", back_populates="quiz", lazy=True, cascade="all, delete-orphan")
    quiz_attempts = db.relationship("QuizAttempt", back_populates="quiz", lazy=True, cascade="all, delete-orphan")

    def __init__(self, lesson_id, title, description=None, time_limit_minutes=None):
        self.lesson_id = lesson_id
        self.title = title
        self.description = description
        self.time_limit_minutes = time_limit_minutes

    def __repr__(self):
        return f"<Quiz {self.quiz_id}: {self.title}>"

