from flask import Blueprint, request, jsonify
from src.models import db
from src.models.quiz_model import Quiz
from src.models.question_model import Question, QuestionType
from src.models.lesson_model import Lesson
from src.models.user_model import UserRole
from src.utils.auth import token_required, role_required

quiz_bp = Blueprint("quiz_bp", __name__, url_prefix="/api/quizzes")

# Create a new quiz (Teacher, Director)
@quiz_bp.route("/", methods=["POST"])
@token_required
@role_required([UserRole.TEACHER, UserRole.DIRECTOR])
def create_quiz(current_user):
    data = request.get_json()
    required_fields = ["lesson_id", "title"]
    if not all(field in data for field in required_fields):
        return jsonify({"message": f"Missing required fields: {", ".join(required_fields)}"}), 400

    try:
        lesson_id = int(data["lesson_id"])
        title = data["title"]
        description = data.get("description")
        time_limit_minutes = data.get("time_limit_minutes")
        if time_limit_minutes is not None:
            time_limit_minutes = int(time_limit_minutes)
    except ValueError:
        return jsonify({"message": "Invalid data type for lesson_id or time_limit_minutes."}), 400

    lesson = Lesson.query.get(lesson_id)
    if not lesson:
        return jsonify({"message": "Lesson not found"}), 404
    
    target_class = lesson.class_obj
    # Authorization: Teacher can only add quizzes to lessons in their classes (unless Director)
    if request.current_user_role == UserRole.TEACHER and target_class.teacher_id != current_user.user_id:
        return jsonify({"message": "Teachers can only add quizzes to lessons in their own classes."}), 403

    try:
        new_quiz = Quiz(
            lesson_id=lesson_id,
            title=title,
            description=description,
            time_limit_minutes=time_limit_minutes
        )
        db.session.add(new_quiz)
        db.session.commit()
        # Prepare questions if provided
        questions_data = data.get("questions", [])
        if questions_data:
            for q_data in questions_data:
                try:
                    q_type = QuestionType(q_data["question_type"])
                    new_question = Question(
                        quiz_id=new_quiz.quiz_id,
                        question_text=q_data["question_text"],
                        question_type=q_type,
                        options=q_data.get("options"),
                        correct_answer_text=q_data.get("correct_answer_text"),
                        points=int(q_data.get("points", 1))
                    )
                    db.session.add(new_question)
                except Exception as qe:
                    # Log this error, but continue creating the quiz itself
                    print(f"Error creating question: {str(qe)}") # For server log
            db.session.commit() # Commit questions

        return jsonify({
            "message": "Quiz created successfully!",
            "quiz_id": new_quiz.quiz_id
        }), 201
    except Exception as e:
        db.session.rollback()
        return jsonify({"message": "Error creating quiz", "error": str(e)}), 500

# Get all quizzes for a lesson (All roles, if authorized for the lesson/class)
@quiz_bp.route("/lesson/<int:lesson_id>", methods=["GET"])
@token_required
def get_quizzes_for_lesson(current_user, lesson_id):
    lesson = Lesson.query.get(lesson_id)
    if not lesson:
        return jsonify({"message": "Lesson not found"}), 404

    # Authorization (similar to lesson access)
    target_class = lesson.class_obj
    if request.current_user_role == UserRole.STUDENT:
        from src.models.enrollment_model import Enrollment
        enrollment = Enrollment.query.filter_by(student_id=current_user.user_id, class_id=target_class.class_id, status="Active").first()
        if not enrollment:
            return jsonify({"message": "Access denied. Student not actively enrolled in the class of this lesson."}), 403
    elif request.current_user_role == UserRole.TEACHER and target_class.teacher_id != current_user.user_id:
         return jsonify({"message": "Teachers can only view quizzes for their own classes."}), 403

    quizzes = Quiz.query.filter_by(lesson_id=lesson_id).all()
    output = []
    for quiz in quizzes:
        output.append({
            "quiz_id": quiz.quiz_id,
            "lesson_id": quiz.lesson_id,
            "title": quiz.title,
            "description": quiz.description,
            "time_limit_minutes": quiz.time_limit_minutes,
            "created_at": quiz.created_at.isoformat()
        })
    return jsonify(output), 200

# Get a specific quiz with its questions (All roles, if authorized)
@quiz_bp.route("/<int:quiz_id>", methods=["GET"])
@token_required
def get_quiz_with_questions(current_user, quiz_id):
    quiz = Quiz.query.get(quiz_id)
    if not quiz:
        return jsonify({"message": "Quiz not found"}), 404

    # Authorization (similar to lesson access)
    lesson = quiz.lesson
    target_class = lesson.class_obj
    if request.current_user_role == UserRole.STUDENT:
        from src.models.enrollment_model import Enrollment
        enrollment = Enrollment.query.filter_by(student_id=current_user.user_id, class_id=target_class.class_id, status="Active").first()
        if not enrollment:
            return jsonify({"message": "Access denied. Student not actively enrolled in the class of this quiz."}), 403
    elif request.current_user_role == UserRole.TEACHER and target_class.teacher_id != current_user.user_id:
         return jsonify({"message": "Teachers can only view quizzes for their own classes."}), 403

    questions_data = []
    for q in quiz.questions:
        # For students, we might not want to send correct_answer_text or full options if it reveals answers before attempt
        # For MVP, we send all details. In a real app, this would be conditional.
        questions_data.append({
            "question_id": q.question_id,
            "question_text": q.question_text,
            "question_type": q.question_type.value,
            "options": q.options, # Students should not see the "correct" key here before attempting
            "points": q.points
        })

    return jsonify({
        "quiz_id": quiz.quiz_id,
        "lesson_id": quiz.lesson_id,
        "title": quiz.title,
        "description": quiz.description,
        "time_limit_minutes": quiz.time_limit_minutes,
        "created_at": quiz.created_at.isoformat(),
        "questions": questions_data
    }), 200

# Update a quiz (Teacher who owns class, Director)
@quiz_bp.route("/<int:quiz_id>", methods=["PUT"])
@token_required
@role_required([UserRole.TEACHER, UserRole.DIRECTOR])
def update_quiz(current_user, quiz_id):
    quiz = Quiz.query.get(quiz_id)
    if not quiz:
        return jsonify({"message": "Quiz not found"}), 404

    lesson = quiz.lesson
    target_class = lesson.class_obj
    # Authorization
    if request.current_user_role == UserRole.TEACHER and target_class.teacher_id != current_user.user_id:
        return jsonify({"message": "Teachers can only update quizzes in their own classes."}), 403

    data = request.get_json()
    if not data:
        return jsonify({"message": "No data provided for update"}), 400

    try:
        if "title" in data: quiz.title = data["title"]
        if "description" in data: quiz.description = data["description"]
        if "time_limit_minutes" in data:
            quiz.time_limit_minutes = int(data["time_limit_minutes"]) if data["time_limit_minutes"] is not None else None
        
        # Updating questions is more complex: involves deleting old ones, adding new/updated ones.
        # For MVP, we'll keep it simple: quiz metadata update only. Question management via separate endpoints or within quiz creation.
        # If questions are provided in the PUT, it could mean replacing all questions.
        # For now, this part is omitted for simplicity in MVP update.

        quiz.updated_at = db.func.current_timestamp()
        db.session.commit()
        return jsonify({"message": "Quiz updated successfully!", "quiz_id": quiz.quiz_id}), 200
    except ValueError as ve:
        return jsonify({"message": f"Invalid data: {str(ve)}"}), 400
    except Exception as e:
        db.session.rollback()
        return jsonify({"message": "Error updating quiz", "error": str(e)}), 500

# Delete a quiz (Teacher who owns class, Director)
@quiz_bp.route("/<int:quiz_id>", methods=["DELETE"])
@token_required
@role_required([UserRole.TEACHER, UserRole.DIRECTOR])
def delete_quiz(current_user, quiz_id):
    quiz = Quiz.query.get(quiz_id)
    if not quiz:
        return jsonify({"message": "Quiz not found"}), 404

    lesson = quiz.lesson
    target_class = lesson.class_obj
    # Authorization
    if request.current_user_role == UserRole.TEACHER and target_class.teacher_id != current_user.user_id:
        return jsonify({"message": "Teachers can only delete quizzes in their own classes."}), 403

    try:
        # Deleting a quiz will also delete its questions and attempts due to cascade settings in models
        db.session.delete(quiz)
        db.session.commit()
        return jsonify({"message": "Quiz and associated questions/attempts deleted successfully!"}), 200
    except Exception as e:
        db.session.rollback()
        return jsonify({"message": "Error deleting quiz", "error": str(e)}), 500

# --- Question Management within a Quiz --- #

@quiz_bp.route("/<int:quiz_id>/questions", methods=["POST"])
@token_required
@role_required([UserRole.TEACHER, UserRole.DIRECTOR])
def add_question_to_quiz(current_user, quiz_id):
    quiz = Quiz.query.get(quiz_id)
    if not quiz:
        return jsonify({"message": "Quiz not found"}), 404

    lesson = quiz.lesson
    target_class = lesson.class_obj
    if request.current_user_role == UserRole.TEACHER and target_class.teacher_id != current_user.user_id:
        return jsonify({"message": "Teachers can only add questions to quizzes in their own classes."}), 403

    data = request.get_json()
    required_fields = ["question_text", "question_type"]
    if not all(field in data for field in required_fields):
        return jsonify({"message": f"Missing required fields for question: {", ".join(required_fields)}"}), 400

    try:
        question_type = QuestionType(data["question_type"])
        new_question = Question(
            quiz_id=quiz_id,
            question_text=data["question_text"],
            question_type=question_type,
            options=data.get("options"),
            correct_answer_text=data.get("correct_answer_text"),
            points=int(data.get("points", 1))
        )
        db.session.add(new_question)
        db.session.commit()
        return jsonify({"message": "Question added to quiz successfully!", "question_id": new_question.question_id}), 201
    except ValueError as ve:
        return jsonify({"message": f"Invalid question data: {str(ve)}"}), 400
    except Exception as e:
        db.session.rollback()
        return jsonify({"message": "Error adding question to quiz", "error": str(e)}), 500

@quiz_bp.route("/questions/<int:question_id>", methods=["PUT"])
@token_required
@role_required([UserRole.TEACHER, UserRole.DIRECTOR])
def update_question(current_user, question_id):
    question = Question.query.get(question_id)
    if not question:
        return jsonify({"message": "Question not found"}), 404

    quiz = question.quiz
    lesson = quiz.lesson
    target_class = lesson.class_obj
    if request.current_user_role == UserRole.TEACHER and target_class.teacher_id != current_user.user_id:
        return jsonify({"message": "Teachers can only update questions in quizzes of their own classes."}), 403

    data = request.get_json()
    if not data:
        return jsonify({"message": "No data provided for update"}), 400

    try:
        if "question_text" in data: question.question_text = data["question_text"]
        if "question_type" in data: question.question_type = QuestionType(data["question_type"])
        if "options" in data: question.options = data["options"]
        if "correct_answer_text" in data: question.correct_answer_text = data["correct_answer_text"]
        if "points" in data: question.points = int(data["points"])
        
        question.updated_at = db.func.current_timestamp()
        db.session.commit()
        return jsonify({"message": "Question updated successfully!", "question_id": question.question_id}), 200
    except ValueError as ve:
        return jsonify({"message": f"Invalid question data: {str(ve)}"}), 400
    except Exception as e:
        db.session.rollback()
        return jsonify({"message": "Error updating question", "error": str(e)}), 500

@quiz_bp.route("/questions/<int:question_id>", methods=["DELETE"])
@token_required
@role_required([UserRole.TEACHER, UserRole.DIRECTOR])
def delete_question(current_user, question_id):
    question = Question.query.get(question_id)
    if not question:
        return jsonify({"message": "Question not found"}), 404

    quiz = question.quiz
    lesson = quiz.lesson
    target_class = lesson.class_obj
    if request.current_user_role == UserRole.TEACHER and target_class.teacher_id != current_user.user_id:
        return jsonify({"message": "Teachers can only delete questions from quizzes in their own classes."}), 403

    try:
        db.session.delete(question)
        db.session.commit()
        return jsonify({"message": "Question deleted successfully!"}), 200
    except Exception as e:
        db.session.rollback()
        return jsonify({"message": "Error deleting question", "error": str(e)}), 500

# --- Quiz Attempt Endpoints --- #

@quiz_bp.route("/<int:quiz_id>/attempt", methods=["POST"])
@token_required
@role_required(UserRole.STUDENT) # Only students can attempt quizzes
def start_or_submit_quiz_attempt(current_user, quiz_id):
    quiz = Quiz.query.get(quiz_id)
    if not quiz:
        return jsonify({"message": "Quiz not found"}), 404

    # Check if student is enrolled in the class of this quiz
    from src.models.enrollment_model import Enrollment
    enrollment = Enrollment.query.join(Lesson, Enrollment.class_id == Lesson.class_id)\
                               .filter(Lesson.lesson_id == quiz.lesson_id, 
                                       Enrollment.student_id == current_user.user_id, 
                                       Enrollment.status == "Active").first()
    if not enrollment:
        return jsonify({"message": "Student not enrolled or not active in the class for this quiz."}), 403

    data = request.get_json()
    answers_data = data.get("answers") # List of {"question_id": id, "answer_text": "..."}

    from src.models.quiz_attempt_model import QuizAttempt, QuizAttemptStatus
    from src.models.student_answer_model import StudentAnswer

    # Check for existing InProgress attempt
    existing_attempt = QuizAttempt.query.filter_by(
        quiz_id=quiz_id, 
        student_id=current_user.user_id,
        status=QuizAttemptStatus.IN_PROGRESS
    ).first()

    if not answers_data: # Starting a new attempt or getting existing InProgress
        if existing_attempt:
            # Return existing InProgress attempt details (or just a message)
            return jsonify({"message": "Quiz attempt already in progress.", "attempt_id": existing_attempt.attempt_id, "status": existing_attempt.status.value}), 200
        else:
            # Start new attempt
            new_attempt = QuizAttempt(quiz_id=quiz_id, student_id=current_user.user_id)
            db.session.add(new_attempt)
            db.session.commit()
            return jsonify({"message": "Quiz attempt started.", "attempt_id": new_attempt.attempt_id, "status": new_attempt.status.value}), 201
    
    # Submitting answers for an attempt
    attempt_id_from_payload = data.get("attempt_id")
    attempt_to_submit = None

    if attempt_id_from_payload:
        attempt_to_submit = QuizAttempt.query.get(attempt_id_from_payload)
      
(Content truncated due to size limit. Use line ranges to read in chunks)