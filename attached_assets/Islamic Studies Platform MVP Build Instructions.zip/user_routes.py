from flask import Blueprint, request, jsonify
from src.models import db
from src.models.user_model import User, UserRole
from src.utils.auth import generate_token, token_required, role_required

user_bp = Blueprint("user_bp", __name__, url_prefix="/api/users")

@user_bp.route("/register", methods=["POST"])
def register_user():
    data = request.get_json()
    if not data or not data.get("email") or not data.get("password") or not data.get("full_name") or not data.get("role"):
        return jsonify({"message": "Missing required fields (email, password, full_name, role)"}), 400

    if User.query.filter_by(email=data["email"]).first():
        return jsonify({"message": "Email already registered"}), 409

    try:
        user_role = UserRole(data["role"]) # Validate role
    except ValueError:
        return jsonify({"message": f"Invalid role. Must be one of: {[role.value for role in UserRole]}"}), 400

    try:
        new_user = User(
            full_name=data["full_name"],
            email=data["email"],
            password=data["password"], # Hashing is done in User model __init__
            role=user_role
        )
        db.session.add(new_user)
        db.session.commit()
        return jsonify({"message": "User registered successfully!", "user_id": new_user.user_id}), 201
    except Exception as e:
        db.session.rollback()
        return jsonify({"message": "Error registering user", "error": str(e)}), 500

@user_bp.route("/login", methods=["POST"])
def login_user():
    data = request.get_json()
    if not data or not data.get("email") or not data.get("password"):
        return jsonify({"message": "Email and password are required"}), 400

    user = User.query.filter_by(email=data["email"]).first()

    if not user or not user.check_password(data["password"]):
        return jsonify({"message": "Invalid email or password"}), 401

    try:
        token = generate_token(user.user_id, user.role)
        return jsonify({
            "message": "Login successful!",
            "token": token,
            "user": {
                "user_id": user.user_id,
                "full_name": user.full_name,
                "email": user.email,
                "role": user.role.value
            }
        }), 200
    except Exception as e:
        return jsonify({"message": "Error generating token", "error": str(e)}), 500

@user_bp.route("/profile", methods=["GET"])
@token_required
def get_profile(current_user):
    # current_user is passed by the token_required decorator
    return jsonify({
        "user_id": current_user.user_id,
        "full_name": current_user.full_name,
        "email": current_user.email,
        "role": current_user.role.value,
        "created_at": current_user.created_at.isoformat() if current_user.created_at else None,
        "updated_at": current_user.updated_at.isoformat() if current_user.updated_at else None
    }), 200

# Example of a role-protected route
@user_bp.route("/director_only", methods=["GET"])
@token_required
@role_required(UserRole.DIRECTOR) # Can also be a list: [UserRole.DIRECTOR, UserRole.TEACHER]
def director_only_route(current_user):
    return jsonify({"message": f"Welcome Director {current_user.full_name}! This is a protected area."}), 200

@user_bp.route("/teacher_only", methods=["GET"])
@token_required
@role_required(UserRole.TEACHER)
def teacher_only_route(current_user):
    return jsonify({"message": f"Welcome Teacher {current_user.full_name}! This is a protected area for teachers."}), 200

@user_bp.route("/student_only", methods=["GET"])
@token_required
@role_required(UserRole.STUDENT)
def student_only_route(current_user):
    return jsonify({"message": f"Welcome Student {current_user.full_name}! This is a protected area for students."}), 200

