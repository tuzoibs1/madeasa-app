from flask import Blueprint, request, jsonify
from src.models import db
from src.models.attendance_model import Attendance, AttendanceStatus
from src.models.enrollment_model import Enrollment
from src.models.user_model import UserRole
from src.utils.auth import token_required, role_required
from datetime import datetime

attendance_bp = Blueprint("attendance_bp", __name__, url_prefix="/api/attendance")

@attendance_bp.route("/check_in_out", methods=["POST"])
@token_required
@role_required([UserRole.TEACHER, UserRole.STUDENT]) # Teachers can mark, students can self-check-in (if allowed by logic)
def record_attendance(current_user):
    data = request.get_json()
    required_fields = ["enrollment_id", "session_date", "status"]
    if not all(field in data for field in required_fields):
        return jsonify({"message": f"Missing required fields: {', '.join(required_fields)}"}), 400

    try:
        enrollment_id = int(data["enrollment_id"])
        session_date_str = data["session_date"]
        status_str = data["status"]
        notes = data.get("notes")
    except ValueError:
        return jsonify({"message": "Invalid data type for enrollment_id or other fields."}), 400

    try:
        session_date = datetime.strptime(session_date_str, "%Y-%m-%d").date()
    except ValueError:
        return jsonify({"message": "Invalid date format for session_date. Use YYYY-MM-DD."}), 400

    try:
        attendance_status = AttendanceStatus(status_str)
    except ValueError:
        return jsonify({"message": f"Invalid status. Must be one of: {[s.value for s in AttendanceStatus]}"}), 400

    enrollment = Enrollment.query.get(enrollment_id)
    if not enrollment:
        return jsonify({"message": "Enrollment not found"}), 404

    # Authorization: Teacher can mark for any student in their class (indirectly via enrollment)
    # Student can only mark their own attendance.
    if request.current_user_role == UserRole.STUDENT and enrollment.student_id != current_user.user_id:
        return jsonify({"message": "Students can only record their own attendance."}), 403
    
    # Further check: if teacher, ensure the enrollment is for a class they teach (more complex, might need class_id in request or deeper query)
    # For MVP, we assume teacher has correct enrollment_id.

    existing_attendance = Attendance.query.filter_by(enrollment_id=enrollment_id, session_date=session_date).first()
    if existing_attendance:
        # Update existing record
        existing_attendance.status = attendance_status
        existing_attendance.notes = notes
        if request.current_user_role == UserRole.TEACHER:
            existing_attendance.recorded_by_teacher_id = current_user.user_id
        existing_attendance.updated_at = datetime.utcnow()
        message = "Attendance record updated successfully!"
    else:
        # Create new record
        new_attendance = Attendance(
            enrollment_id=enrollment_id,
            session_date=session_date,
            status=attendance_status,
            notes=notes
        )
        if request.current_user_role == UserRole.TEACHER:
            new_attendance.recorded_by_teacher_id = current_user.user_id
        db.session.add(new_attendance)
        message = "Attendance recorded successfully!"

    try:
        db.session.commit()
        return jsonify({"message": message}), 200 if existing_attendance else 201
    except Exception as e:
        db.session.rollback()
        return jsonify({"message": "Error recording attendance", "error": str(e)}), 500

@attendance_bp.route("/student/<int:student_id>/class/<int:class_id>", methods=["GET"])
@token_required
@role_required([UserRole.DIRECTOR, UserRole.TEACHER, UserRole.STUDENT])
def get_student_attendance_for_class(current_user, student_id, class_id):
    enrollment = Enrollment.query.filter_by(student_id=student_id, class_id=class_id).first()
    if not enrollment:
        return jsonify({"message": "Student is not enrolled in this class or enrollment not found."}), 404

    # Authorization
    if request.current_user_role == UserRole.STUDENT and enrollment.student_id != current_user.user_id:
        return jsonify({"message": "Students can only view their own attendance."}), 403
    # Teachers should only be able to view attendance for classes they teach (more complex check needed for MVP)
    # Directors can view all.

    attendances = Attendance.query.filter_by(enrollment_id=enrollment.enrollment_id).order_by(Attendance.session_date.desc()).all()
    
    output = []
    for att in attendances:
        output.append({
            "attendance_id": att.attendance_id,
            "session_date": att.session_date.isoformat(),
            "status": att.status.value,
            "notes": att.notes,
            "recorded_by_teacher_id": att.recorded_by_teacher_id,
            "updated_at": att.updated_at.isoformat()
        })
    return jsonify(output), 200

@attendance_bp.route("/class/<int:class_id>/date/<string:session_date_str>", methods=["GET"])
@token_required
@role_required([UserRole.DIRECTOR, UserRole.TEACHER])
def get_class_attendance_for_date(current_user, class_id, session_date_str):
    try:
        session_date = datetime.strptime(session_date_str, "%Y-%m-%d").date()
    except ValueError:
        return jsonify({"message": "Invalid date format for session_date. Use YYYY-MM-DD."}), 400

    # This query is a bit more complex: get all enrollments for the class, then join attendance for that date.
    # For MVP, we can simplify or make multiple queries.
    # Assuming teacher is authorized for this class_id (further checks for non-director roles)

    attendances = db.session.query(Attendance, Enrollment, User).join(Enrollment, Attendance.enrollment_id == Enrollment.enrollment_id).join(User, Enrollment.student_id == User.user_id).filter(Enrollment.class_id == class_id, Attendance.session_date == session_date).all()

    output = []
    for att, enr, usr in attendances:
        output.append({
            "attendance_id": att.attendance_id,
            "student_id": enr.student_id,
            "student_name": usr.full_name,
            "session_date": att.session_date.isoformat(),
            "status": att.status.value,
            "notes": att.notes,
            "recorded_by_teacher_id": att.recorded_by_teacher_id
        })
    return jsonify(output), 200

