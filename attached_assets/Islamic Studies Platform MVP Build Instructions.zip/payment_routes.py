from flask import Blueprint, request, jsonify
from src.models import db
from src.models.payment_model import Payment, PaymentStatus
from src.models.user_model import User, UserRole
from src.models.class_model import Class
from src.utils.auth import token_required, role_required
from datetime import datetime

payment_bp = Blueprint("payment_bp", __name__, url_prefix="/api/payments")

# Record a new payment (Director)
@payment_bp.route("/", methods=["POST"])
@token_required
@role_required(UserRole.DIRECTOR)
def record_payment(current_user):
    data = request.get_json()
    required_fields = ["student_id", "amount", "payment_date"]
    if not all(field in data for field in required_fields):
        return jsonify({"message": f"Missing required fields: {", ".join(required_fields)}"}), 400

    try:
        student_id = int(data["student_id"])
        amount_str = data["amount"]
        payment_date_str = data["payment_date"]
        class_id = data.get("class_id")
        if class_id is not None:
            class_id = int(class_id)
        payment_method = data.get("payment_method", "Manual")
        transaction_id = data.get("transaction_id")
        status_str = data.get("status", "Paid") # Default to Paid for manual entry by Director
        description = data.get("description")
    except ValueError:
        return jsonify({"message": "Invalid data type for student_id, class_id or amount."}), 400

    try:
        amount = float(amount_str) # Using float for Numeric(10,2)
    except ValueError:
        return jsonify({"message": "Invalid format for amount. Must be a number."}), 400

    try:
        payment_date = datetime.strptime(payment_date_str, "%Y-%m-%d").date()
    except ValueError:
        return jsonify({"message": "Invalid date format for payment_date. Use YYYY-MM-DD."}), 400

    try:
        status = PaymentStatus(status_str)
    except ValueError:
        return jsonify({"message": f"Invalid status. Must be one of: {[s.value for s in PaymentStatus]}"}), 400

    student = User.query.get(student_id)
    if not student or student.role != UserRole.STUDENT:
        return jsonify({"message": "Invalid student ID or user is not a student."}), 404

    if class_id:
        target_class = Class.query.get(class_id)
        if not target_class:
            return jsonify({"message": "Specified class not found."}), 404

    try:
        new_payment = Payment(
            student_id=student_id,
            class_id=class_id,
            amount=amount,
            payment_date=payment_date,
            payment_method=payment_method,
            transaction_id=transaction_id,
            status=status,
            description=description,
            recorded_by_director_id=current_user.user_id
        )
        db.session.add(new_payment)
        db.session.commit()
        return jsonify({
            "message": "Payment recorded successfully!",
            "payment_id": new_payment.payment_id
        }), 201
    except Exception as e:
        db.session.rollback()
        return jsonify({"message": "Error recording payment", "error": str(e)}), 500

# Get all payments for a student (Director, or Student themselves)
@payment_bp.route("/student/<int:student_id>", methods=["GET"])
@token_required
@role_required([UserRole.DIRECTOR, UserRole.STUDENT])
def get_student_payments(current_user, student_id):
    if request.current_user_role == UserRole.STUDENT and current_user.user_id != student_id:
        return jsonify({"message": "Students can only view their own payment records."}), 403

    student = User.query.get(student_id)
    if not student or student.role != UserRole.STUDENT:
        return jsonify({"message": "Student not found or user is not a student."}), 404

    payments = Payment.query.filter_by(student_id=student_id).order_by(Payment.payment_date.desc()).all()
    output = []
    for p in payments:
        output.append({
            "payment_id": p.payment_id,
            "student_id": p.student_id,
            "class_id": p.class_id,
            "class_name": p.class_obj.class_name if p.class_obj else None,
            "amount": str(p.amount), # Convert Decimal to string
            "payment_date": p.payment_date.isoformat(),
            "payment_method": p.payment_method,
            "transaction_id": p.transaction_id,
            "status": p.status.value,
            "description": p.description,
            "recorded_by_director_id": p.recorded_by_director_id,
            "created_at": p.created_at.isoformat()
        })
    return jsonify(output), 200

# Get a specific payment (Director, or Student if it's theirs)
@payment_bp.route("/<int:payment_id>", methods=["GET"])
@token_required
@role_required([UserRole.DIRECTOR, UserRole.STUDENT])
def get_payment(current_user, payment_id):
    payment = Payment.query.get(payment_id)
    if not payment:
        return jsonify({"message": "Payment record not found"}), 404

    if request.current_user_role == UserRole.STUDENT and payment.student_id != current_user.user_id:
        return jsonify({"message": "Students can only view their own payment records."}), 403

    return jsonify({
        "payment_id": payment.payment_id,
        "student_id": payment.student_id,
        "student_name": payment.student.full_name if payment.student else None,
        "class_id": payment.class_id,
        "class_name": payment.class_obj.class_name if payment.class_obj else None,
        "amount": str(payment.amount),
        "payment_date": payment.payment_date.isoformat(),
        "payment_method": payment.payment_method,
        "transaction_id": payment.transaction_id,
        "status": payment.status.value,
        "description": payment.description,
        "recorded_by_director_id": payment.recorded_by_director_id,
        "recorded_by_director_name": payment.recorded_by_director.full_name if payment.recorded_by_director else None,
        "created_at": payment.created_at.isoformat(),
        "updated_at": payment.updated_at.isoformat()
    }), 200

# Update a payment (Director)
@payment_bp.route("/<int:payment_id>", methods=["PUT"])
@token_required
@role_required(UserRole.DIRECTOR)
def update_payment(current_user, payment_id):
    payment = Payment.query.get(payment_id)
    if not payment:
        return jsonify({"message": "Payment record not found"}), 404

    data = request.get_json()
    if not data:
        return jsonify({"message": "No data provided for update"}), 400

    try:
        if "student_id" in data: payment.student_id = int(data["student_id"])
        if "class_id" in data: payment.class_id = int(data["class_id"]) if data["class_id"] is not None else None
        if "amount" in data: payment.amount = float(data["amount"])
        if "payment_date" in data: payment.payment_date = datetime.strptime(data["payment_date"], "%Y-%m-%d").date()
        if "payment_method" in data: payment.payment_method = data["payment_method"]
        if "transaction_id" in data: payment.transaction_id = data["transaction_id"]
        if "status" in data: payment.status = PaymentStatus(data["status"])
        if "description" in data: payment.description = data["description"]
        
        payment.updated_at = db.func.current_timestamp()
        # Ensure the director who is updating is recorded, or keep original if not specified
        payment.recorded_by_director_id = current_user.user_id 

        db.session.commit()
        return jsonify({"message": "Payment record updated successfully!", "payment_id": payment.payment_id}), 200
    except ValueError as ve:
        return jsonify({"message": f"Invalid data: {str(ve)}"}), 400
    except Exception as e:
        db.session.rollback()
        return jsonify({"message": "Error updating payment record", "error": str(e)}), 500

# Delete a payment (Director)
@payment_bp.route("/<int:payment_id>", methods=["DELETE"])
@token_required
@role_required(UserRole.DIRECTOR)
def delete_payment(current_user, payment_id):
    payment = Payment.query.get(payment_id)
    if not payment:
        return jsonify({"message": "Payment record not found"}), 404

    try:
        db.session.delete(payment)
        db.session.commit()
        return jsonify({"message": "Payment record deleted successfully!"}), 200
    except Exception as e:
        db.session.rollback()
        return jsonify({"message": "Error deleting payment record", "error": str(e)}), 500

# Get all payments (Director)
@payment_bp.route("/all", methods=["GET"])
@token_required
@role_required(UserRole.DIRECTOR)
def get_all_payments(current_user):
    payments = Payment.query.order_by(Payment.payment_date.desc()).all()
    output = []
    for p in payments:
        output.append({
            "payment_id": p.payment_id,
            "student_id": p.student_id,
            "student_name": p.student.full_name if p.student else None,
            "class_id": p.class_id,
            "class_name": p.class_obj.class_name if p.class_obj else None,
            "amount": str(p.amount),
            "payment_date": p.payment_date.isoformat(),
            "payment_method": p.payment_method,
            "status": p.status.value,
            "description": p.description,
            "recorded_by_director_name": p.recorded_by_director.full_name if p.recorded_by_director else None,
            "created_at": p.created_at.isoformat()
        })
    return jsonify(output), 200

