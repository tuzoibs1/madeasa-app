# Islamic Studies Platform - Database Schema

This document outlines the database schema for the Islamic Studies Learning Platform MVP.

## Table Definitions

### 1. Users

Stores information about all users of the platform (Directors, Teachers, Students).

-   `user_id` (INT, Primary Key, Auto Increment)
-   `full_name` (VARCHAR(255), Not Null)
-   `email` (VARCHAR(255), Not Null, Unique)
-   `password_hash` (VARCHAR(255), Not Null)
-   `role` (ENUM('Director', 'Teacher', 'Student'), Not Null)
-   `created_at` (TIMESTAMP, Default CURRENT_TIMESTAMP)
-   `updated_at` (TIMESTAMP, Default CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP)

### 2. Classes

Stores information about the classes offered.

-   `class_id` (INT, Primary Key, Auto Increment)
-   `class_name` (VARCHAR(255), Not Null)
-   `description` (TEXT, Nullable)
-   `teacher_id` (INT, Foreign Key -> Users.user_id, Nullable) - Nullable if a class can be created before a teacher is assigned.
-   `created_at` (TIMESTAMP, Default CURRENT_TIMESTAMP)
-   `updated_at` (TIMESTAMP, Default CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP)

### 3. Enrollment

Tracks student enrollment in classes (junction table between Users and Classes).

-   `enrollment_id` (INT, Primary Key, Auto Increment)
-   `student_id` (INT, Foreign Key -> Users.user_id, Not Null)
-   `class_id` (INT, Foreign Key -> Classes.class_id, Not Null)
-   `enrollment_date` (DATE, Not Null)
-   `status` (ENUM('Active', 'Completed', 'Dropped'), Default 'Active')
-   `created_at` (TIMESTAMP, Default CURRENT_TIMESTAMP)
-   `updated_at` (TIMESTAMP, Default CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP)
-   **Constraint:** UNIQUE (`student_id`, `class_id`) to prevent duplicate enrollments.

### 4. Attendance

Tracks student attendance for each class session.

-   `attendance_id` (INT, Primary Key, Auto Increment)
-   `enrollment_id` (INT, Foreign Key -> Enrollment.enrollment_id, Not Null)
-   `session_date` (DATE, Not Null)
-   `status` (ENUM('Present', 'Absent', 'Late', 'Excused'), Not Null)
-   `notes` (TEXT, Nullable)
-   `recorded_by_teacher_id` (INT, Foreign Key -> Users.user_id, Nullable) - Tracks which teacher recorded it.
-   `created_at` (TIMESTAMP, Default CURRENT_TIMESTAMP)
-   `updated_at` (TIMESTAMP, Default CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP)
-   **Constraint:** UNIQUE (`enrollment_id`, `session_date`) to prevent duplicate attendance records for the same student on the same day for the same class.

### 5. Memorization_Progress

Tracks student progress in memorizing Qur'anic content or other lesson material.

-   `progress_id` (INT, Primary Key, Auto Increment)
-   `student_id` (INT, Foreign Key -> Users.user_id, Not Null)
-   `lesson_id` (INT, Foreign Key -> Lessons.lesson_id, Not Null) - Assuming progress is tracked per lesson.
-   `surah_juz_aya_start` (VARCHAR(100), Nullable) - e.g., "Surah Al-Baqarah, Ayah 1" or "Juz 1, Page 5"
-   `surah_juz_aya_end` (VARCHAR(100), Nullable) - e.g., "Surah Al-Baqarah, Ayah 5" or "Juz 1, Page 10"
-   `status` (ENUM('Not Started', 'In Progress', 'Memorized', 'Revised'), Default 'Not Started')
-   `last_tested_date` (DATE, Nullable)
-   `accuracy_score` (DECIMAL(5,2), Nullable) - e.g., percentage
-   `notes` (TEXT, Nullable)
-   `teacher_id_evaluator` (INT, Foreign Key -> Users.user_id, Nullable)
-   `created_at` (TIMESTAMP, Default CURRENT_TIMESTAMP)
-   `updated_at` (TIMESTAMP, Default CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP)

### 6. Lessons

Stores information about individual lessons within a class.

-   `lesson_id` (INT, Primary Key, Auto Increment)
-   `class_id` (INT, Foreign Key -> Classes.class_id, Not Null)
-   `title` (VARCHAR(255), Not Null)
-   `content_type` (ENUM('Text', 'Video', 'Audio', 'PDF', 'ExternalLink'), Default 'Text')
-   `content_value` (TEXT, Nullable) - Could be raw text, URL to video/audio/PDF, or external link.
-   `lesson_order` (INT, Nullable) - For sequencing lessons within a class.
-   `created_at` (TIMESTAMP, Default CURRENT_TIMESTAMP)
-   `updated_at` (TIMESTAMP, Default CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP)

### 7. Quizzes

Stores information about quizzes associated with lessons.

-   `quiz_id` (INT, Primary Key, Auto Increment)
-   `lesson_id` (INT, Foreign Key -> Lessons.lesson_id, Not Null)
-   `title` (VARCHAR(255), Not Null)
-   `description` (TEXT, Nullable)
-   `time_limit_minutes` (INT, Nullable)
-   `created_at` (TIMESTAMP, Default CURRENT_TIMESTAMP)
-   `updated_at` (TIMESTAMP, Default CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP)

### 8. Questions (Associated with Quizzes)

Stores individual questions for each quiz.

-   `question_id` (INT, Primary Key, Auto Increment)
-   `quiz_id` (INT, Foreign Key -> Quizzes.quiz_id, Not Null)
-   `question_text` (TEXT, Not Null)
-   `question_type` (ENUM('MultipleChoice', 'TrueFalse', 'ShortAnswer'), Not Null)
-   `options` (JSON, Nullable) - For MultipleChoice/TrueFalse, e.g., {"A": "Option 1", "B": "Option 2", "correct": "A"}
-   `correct_answer_text` (TEXT, Nullable) - For ShortAnswer
-   `points` (INT, Default 1)
-   `created_at` (TIMESTAMP, Default CURRENT_TIMESTAMP)
-   `updated_at` (TIMESTAMP, Default CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP)

### 9. Quiz_Attempts

Stores student attempts at quizzes.

-   `attempt_id` (INT, Primary Key, Auto Increment)
-   `quiz_id` (INT, Foreign Key -> Quizzes.quiz_id, Not Null)
-   `student_id` (INT, Foreign Key -> Users.user_id, Not Null)
-   `start_time` (TIMESTAMP, Nullable)
-   `end_time` (TIMESTAMP, Nullable)
-   `score` (DECIMAL(5,2), Nullable)
-   `status` (ENUM('InProgress', 'Completed', 'Graded'), Default 'InProgress')
-   `created_at` (TIMESTAMP, Default CURRENT_TIMESTAMP)
-   `updated_at` (TIMESTAMP, Default CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP)

### 10. Student_Answers (Associated with Quiz_Attempts)

Stores student's answers for each question in a quiz attempt.

-   `student_answer_id` (INT, Primary Key, Auto Increment)
-   `attempt_id` (INT, Foreign Key -> Quiz_Attempts.attempt_id, Not Null)
-   `question_id` (INT, Foreign Key -> Questions.question_id, Not Null)
-   `answer_text` (TEXT, Nullable)
-   `is_correct` (BOOLEAN, Nullable)
-   `points_awarded` (INT, Nullable)
-   `created_at` (TIMESTAMP, Default CURRENT_TIMESTAMP)
-   `updated_at` (TIMESTAMP, Default CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP)

### 11. Payments

Tracks payment information for students (MVP: manual tracking).

-   `payment_id` (INT, Primary Key, Auto Increment)
-   `student_id` (INT, Foreign Key -> Users.user_id, Not Null)
-   `class_id` (INT, Foreign Key -> Classes.class_id, Nullable) - If payment is for a specific class.
-   `amount` (DECIMAL(10,2), Not Null)
-   `payment_date` (DATE, Not Null)
-   `payment_method` (VARCHAR(50), Default 'Manual') - e.g., 'Cash', 'Bank Transfer', 'Stripe_MVP_Placeholder'
-   `transaction_id` (VARCHAR(255), Nullable) - For external reference if any.
-   `status` (ENUM('Pending', 'Paid', 'Failed', 'Refunded'), Default 'Pending')
-   `description` (TEXT, Nullable) - e.g., "Monthly fee for Qur'anic Studies - May"
-   `recorded_by_director_id` (INT, Foreign Key -> Users.user_id, Nullable)
-   `created_at` (TIMESTAMP, Default CURRENT_TIMESTAMP)
-   `updated_at` (TIMESTAMP, Default CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP)

## Relationships Summary

-   **Users** to **Classes**: One-to-Many (A teacher can teach multiple classes; a class has one teacher). Implemented via `teacher_id` in `Classes`.
-   **Users (Students)** to **Classes**: Many-to-Many. Implemented via the `Enrollment` junction table.
-   **Enrollment** to **Attendance**: One-to-Many (An enrollment can have multiple attendance records).
-   **Users (Students)** to **Memorization_Progress**: One-to-Many (A student can have multiple memorization progress entries).
-   **Lessons** to **Memorization_Progress**: One-to-Many (A lesson can be the subject of multiple memorization progress entries).
-   **Classes** to **Lessons**: One-to-Many (A class can have multiple lessons).
-   **Lessons** to **Quizzes**: One-to-Many (A lesson can have multiple quizzes).
-   **Quizzes** to **Questions**: One-to-Many (A quiz can have multiple questions).
-   **Quizzes** to **Quiz_Attempts**: One-to-Many (A quiz can be attempted multiple times by different students).
-   **Users (Students)** to **Quiz_Attempts**: One-to-Many (A student can have multiple quiz attempts).
-   **Quiz_Attempts** to **Student_Answers**: One-to-Many (An attempt has multiple answers).
-   **Questions** to **Student_Answers**: One-to-Many (A question can have multiple student answers across different attempts).
-   **Users (Students)** to **Payments**: One-to-Many (A student can have multiple payment records).
-   **Classes** to **Payments**: One-to-Many (A class can be associated with multiple payments, if payments are class-specific).

This schema provides a foundation for the MVP. It can be extended as the platform evolves.
