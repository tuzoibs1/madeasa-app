import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import LoginPage from './pages/LoginPage';
import RegisterPage from './pages/RegisterPage';
import DirectorDashboard from './pages/DirectorDashboard';
import TeacherDashboard from './pages/TeacherDashboard';
import StudentDashboard from './pages/StudentDashboard';
import Layout from './components/Layout';
import ProtectedRoute from './components/ProtectedRoute';

// Mock auth state, replace with actual context/state management
const isAuthenticated = () => !!localStorage.getItem('token');
const getUserRole = () => localStorage.getItem('role');

function App() {
  return (
    <Router>
      <Layout>
        <Routes>
          <Route path="/login" element={<LoginPage />} />
          <Route path="/register" element={<RegisterPage />} />

          {/* Protected Routes */}
          <Route 
            path="/director" 
            element={
              <ProtectedRoute roles={['Director']}>
                <DirectorDashboard />
              </ProtectedRoute>
            }
          />
          <Route 
            path="/teacher" 
            element={
              <ProtectedRoute roles={['Teacher']}>
                <TeacherDashboard />
              </ProtectedRoute>
            }
          />
          <Route 
            path="/student" 
            element={
              <ProtectedRoute roles={['Student']}>
                <StudentDashboard />
              </ProtectedRoute>
            }
          />

          {/* Default route: redirect to login or appropriate dashboard */}
          <Route 
            path="/" 
            element={
              isAuthenticated() ? (
                getUserRole() === 'Director' ? <Navigate to="/director" /> :
                getUserRole() === 'Teacher' ? <Navigate to="/teacher" /> :
                getUserRole() === 'Student' ? <Navigate to="/student" /> :
                <Navigate to="/login" /> // Fallback if role is unknown
              ) : (
                <Navigate to="/login" />
              )
            }
          />
          <Route path="*" element={<Navigate to="/" />} /> {/* Catch all other routes */}
        </Routes>
      </Layout>
    </Router>
  );
}

export default App;

