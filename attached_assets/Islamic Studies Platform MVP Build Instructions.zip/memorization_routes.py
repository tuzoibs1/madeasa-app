from flask import Blueprint, request, jsonify
from src.models import db
from src.models.memorization_progress_model import MemorizationProgress, MemorizationStatus
from src.models.user_model import User, UserRole
from src.models.lesson_model import Lesson
from src.utils.auth import token_required, role_required
from datetime import datetime

memorization_bp = Blueprint("memorization_bp", __name__, url_prefix="/api/memorization")

@memorization_bp.route("/progress", methods=["POST"])
@token_required
@role_required([UserRole.TEACHER, UserRole.STUDENT]) # Teachers can update, students can update their own
def track_memorization_progress(current_user):
    data = request.get_json()
    required_fields = ["student_id", "lesson_id", "status"]
    if not all(field in data for field in required_fields):
        return jsonify({"message": f"Missing required fields: {', '.join(required_fields)}"}), 400

    try:
        student_id = int(data["student_id"])
        lesson_id = int(data["lesson_id"])
        status_str = data["status"]
        surah_juz_aya_start = data.get("surah_juz_aya_start")
        surah_juz_aya_end = data.get("surah_juz_aya_end")
        last_tested_date_str = data.get("last_tested_date")
        accuracy_score_str = data.get("accuracy_score")
        notes = data.get("notes")
    except ValueError:
        return jsonify({"message": "Invalid data type for student_id, lesson_id or accuracy_score."}), 400

    # Authorization: Student can only update their own progress.
    if request.current_user_role == UserRole.STUDENT and student_id != current_user.user_id:
        return jsonify({"message": "Students can only track their own memorization progress."}), 403

    student = User.query.get(student_id)
    if not student or student.role != UserRole.STUDENT:
        return jsonify({"message": "Invalid student ID or user is not a student."}), 404

    lesson = Lesson.query.get(lesson_id)
    if not lesson:
        return jsonify({"message": "Lesson not found."}), 404

    try:
        status = MemorizationStatus(status_str)
    except ValueError:
        return jsonify({"message": f"Invalid status. Must be one of: {[s.value for s in MemorizationStatus]}"}), 400

    last_tested_date = None
    if last_tested_date_str:
        try:
            last_tested_date = datetime.strptime(last_tested_date_str, "%Y-%m-%d").date()
        except ValueError:
            return jsonify({"message": "Invalid date format for last_tested_date. Use YYYY-MM-DD."}), 400

    accuracy_score = None
    if accuracy_score_str is not None:
        try:
            accuracy_score = float(accuracy_score_str) # Using float for Numeric(5,2)
        except ValueError:
            return jsonify({"message": "Invalid format for accuracy_score. Must be a number."}), 400

    # Check if progress record already exists for this student and lesson
    progress = MemorizationProgress.query.filter_by(student_id=student_id, lesson_id=lesson_id).first()

    if progress:
        # Update existing progress
        progress.status = status
        progress.surah_juz_aya_start = surah_juz_aya_start if surah_juz_aya_start is not None else progress.surah_juz_aya_start
        progress.surah_juz_aya_end = surah_juz_aya_end if surah_juz_aya_end is not None else progress.surah_juz_aya_end
        progress.last_tested_date = last_tested_date if last_tested_date is not None else progress.last_tested_date
        progress.accuracy_score = accuracy_score if accuracy_score is not None else progress.accuracy_score
        progress.notes = notes if notes is not None else progress.notes
        if request.current_user_role == UserRole.TEACHER:
            progress.teacher_id_evaluator = current_user.user_id
        progress.updated_at = datetime.utcnow()
        message = "Memorization progress updated successfully!"
    else:
        # Create new progress record
        progress = MemorizationProgress(
            student_id=student_id,
            lesson_id=lesson_id,
            status=status,
            surah_juz_aya_start=surah_juz_aya_start,
            surah_juz_aya_end=surah_juz_aya_end,
            last_tested_date=last_tested_date,
            accuracy_score=accuracy_score,
            notes=notes
        )
        if request.current_user_role == UserRole.TEACHER:
            progress.teacher_id_evaluator = current_user.user_id
        db.session.add(progress)
        message = "Memorization progress recorded successfully!"

    try:
        db.session.commit()
        return jsonify({"message": message, "progress_id": progress.progress_id}), 200 if existing_attendance else 201 # Typo: should be 'progress' not 'existing_attendance'
    except Exception as e:
        db.session.rollback()
        return jsonify({"message": "Error tracking memorization progress", "error": str(e)}), 500

@memorization_bp.route("/student/<int:student_id>", methods=["GET"])
@token_required
@role_required([UserRole.DIRECTOR, UserRole.TEACHER, UserRole.STUDENT])
def get_student_memorization_progress(current_user, student_id):
    # Authorization: Student can only view their own progress.
    if request.current_user_role == UserRole.STUDENT and student_id != current_user.user_id:
        return jsonify({"message": "Students can only view their own memorization progress."}), 403
    
    student = User.query.get(student_id)
    if not student or student.role != UserRole.STUDENT:
        return jsonify({"message": "Invalid student ID or user is not a student."}), 404

    # Teachers should only be able to view progress for students in their classes (more complex check for MVP)
    # Directors can view all.

    progress_list = MemorizationProgress.query.filter_by(student_id=student_id).join(Lesson).order_by(Lesson.class_id, Lesson.lesson_order, MemorizationProgress.updated_at.desc()).all()
    
    output = []
    for p in progress_list:
        output.append({
            "progress_id": p.progress_id,
            "student_id": p.student_id,
            "lesson_id": p.lesson_id,
            "lesson_title": p.lesson.title if p.lesson else None,
            "class_id": p.lesson.class_id if p.lesson else None,
            "surah_juz_aya_start": p.surah_juz_aya_start,
            "surah_juz_aya_end": p.surah_juz_aya_end,
            "status": p.status.value,
            "last_tested_date": p.last_tested_date.isoformat() if p.last_tested_date else None,
            "accuracy_score": str(p.accuracy_score) if p.accuracy_score is not None else None, # Convert Decimal to string
            "notes": p.notes,
            "teacher_id_evaluator": p.teacher_id_evaluator,
            "updated_at": p.updated_at.isoformat()
        })
    return jsonify(output), 200

@memorization_bp.route("/lesson/<int:lesson_id>/student/<int:student_id>", methods=["GET"])
@token_required
@role_required([UserRole.DIRECTOR, UserRole.TEACHER, UserRole.STUDENT])
def get_progress_for_lesson_student(current_user, lesson_id, student_id):
    # Authorization
    if request.current_user_role == UserRole.STUDENT and student_id != current_user.user_id:
        return jsonify({"message": "Students can only view their own memorization progress."}), 403

    progress = MemorizationProgress.query.filter_by(lesson_id=lesson_id, student_id=student_id).first()
    if not progress:
        return jsonify({"message": "No memorization progress found for this student and lesson."}), 404
    
    return jsonify({
        "progress_id": progress.progress_id,
        "student_id": progress.student_id,
        "lesson_id": progress.lesson_id,
        "surah_juz_aya_start": progress.surah_juz_aya_start,
        "surah_juz_aya_end": progress.surah_juz_aya_end,
        "status": progress.status.value,
        "last_tested_date": progress.last_tested_date.isoformat() if progress.last_tested_date else None,
        "accuracy_score": str(progress.accuracy_score) if progress.accuracy_score is not None else None,
        "notes": progress.notes,
        "teacher_id_evaluator": progress.teacher_id_evaluator,
        "updated_at": progress.updated_at.isoformat()
    }), 200

